/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Patient, RiskLevel, Visit } from '../types';

export interface RuleResult {
  triggered: boolean;
  message: string;
  finding: string;
  intervention: string;
}

export interface AssessmentResult {
  riskCategory: RiskLevel;
  triggeredRules: string[];
  clinicalFindings: string[];
  recommendedInterventions: string[];
  referralNeeded: boolean;
  followUpDate: string;
  mlProbability: number;
  mlConfidence: number;
}

// 1. Definition of clinical rules for modular execution and update
export const EMERGENCY_RULES: Array<{
  id: string;
  name: string;
  evaluate: (patient: Patient, visit: Partial<Visit>) => RuleResult;
}> = [
  {
    id: 'E1_CONVULSIONS',
    name: 'Active Convulsions',
    evaluate: (_, v) => ({
      triggered: !!v.symptoms?.convulsions,
      message: 'Patient presenting with active convulsions (suggestive of Eclampsia).',
      finding: 'Active Convulsions (Eclampsia Risk)',
      intervention: 'Administer loading dose of Magnesium Sulfate (MgSO4) 4g IV / 10g IM, secure airway, and arrange immediate emergency transfer.'
    })
  },
  {
    id: 'E2_SEVERE_HYPERTENSION',
    name: 'Severe Hypertension Crisis',
    evaluate: (_, v) => {
      const sys = v.systolic || 0;
      const dia = v.diastolic || 0;
      const triggered = sys >= 160 || dia >= 110;
      return {
        triggered,
        message: `Blood pressure is critically high: ${sys}/${dia} mmHg.`,
        finding: `Severe Hypertension (${sys}/${dia} mmHg)`,
        intervention: 'Administer antihypertensive therapy (e.g., Hydralazine 5mg IV slowly or Labetalol 20mg IV) and monitor BP closely.'
      };
    }
  },
  {
    id: 'E3_SEVERE_BLEEDING',
    name: 'Severe Antepartum Bleeding',
    evaluate: (_, v) => ({
      triggered: !!v.symptoms?.bleeding && v.gestationalAge !== undefined && v.gestationalAge > 20,
      message: 'Patient presenting with severe vaginal bleeding in late pregnancy (Antepartum Haemorrhage).',
      finding: 'Severe Antepartum Haemorrhage',
      intervention: 'Establish large-bore IV lines, insert urinary catheter, do NOT perform vaginal examination, and arrange urgent transport.'
    })
  },
  {
    id: 'E4_FETAL_DISTRESS',
    name: 'Critical Fetal Distress',
    evaluate: (_, v) => {
      const fhr = v.fetalHeartRate || 0;
      const triggered = v.gestationalAge !== undefined && v.gestationalAge >= 24 && (fhr > 0 && (fhr < 100 || fhr > 170 || v.fetalMovement === 'absent'));
      return {
        triggered,
        message: `Critical fetal distress indicators: FHR is ${fhr} bpm or fetal movement is absent.`,
        finding: `Critical Fetal Distress (FHR: ${fhr} bpm, Movement: ${v.fetalMovement || 'unknown'})`,
        intervention: 'Administer maternal oxygen, place patient on left lateral position, run IV fluids, and refer urgently for emergency C-section.'
      };
    }
  }
];

export const HIGH_RISK_RULES: Array<{
  id: string;
  name: string;
  evaluate: (patient: Patient, visit: Partial<Visit>) => RuleResult;
}> = [
  {
    id: 'H1_SEVERE_ANAEMIA',
    name: 'Severe Anaemia',
    evaluate: (_, v) => {
      const hb = v.hb || 0;
      const triggered = hb > 0 && hb < 7;
      return {
        triggered,
        message: `Haemoglobin level is critically low: ${hb} g/dL, indicating severe anaemia.`,
        finding: `Severe Anaemia (Hb: ${hb} g/dL)`,
        intervention: 'Refer immediately to General Hospital for blood transfusion and parenteral iron therapy.'
      };
    }
  },
  {
    id: 'H2_PREECLAMPSIA_DANGER',
    name: 'Suspected Preeclampsia',
    evaluate: (_, v) => {
      const sys = v.systolic || 0;
      const dia = v.diastolic || 0;
      const hasProtein = v.urineProtein && v.urineProtein !== 'negative';
      const hasSymptoms = v.symptoms?.headache || v.symptoms?.blurredVision || v.symptoms?.swelling;
      const triggered = (sys >= 140 || dia >= 90) && (hasProtein || hasSymptoms);
      return {
        triggered,
        message: `Elevated BP (${sys}/${dia} mmHg) with proteinuria (${v.urineProtein || 'negative'}) or severe neurological symptoms (headache, vision changes).`,
        finding: `Suspected Preeclampsia (BP: ${sys}/${dia} mmHg, Protein: ${v.urineProtein || 'none'})`,
        intervention: 'Admit to facility, initiate MgSO4 prophylaxis protocol, administer oral Methyldopa 250mg, and refer to obstetrician.'
      };
    }
  },
  {
    id: 'H3_MODERATE_HYPERTENSION',
    name: 'Hypertension in Pregnancy',
    evaluate: (_, v) => {
      const sys = v.systolic || 0;
      const dia = v.diastolic || 0;
      const triggered = (sys >= 140 && sys < 160) || (dia >= 90 && dia < 110);
      return {
        triggered,
        message: `Elevated blood pressure: ${sys}/${dia} mmHg.`,
        finding: `Gestational Hypertension (${sys}/${dia} mmHg)`,
        intervention: 'Start oral antihypertensive (Methyldopa or Labetalol), monitor blood pressure twice weekly, and screen weekly for proteinuria.'
      };
    }
  },
  {
    id: 'H4_PREV_CS_AND_PLACENTA_PREVIA',
    name: 'Previous C-Section Risk',
    evaluate: (p, v) => {
      const triggered = p.previousCS && (v.presentation === 'breech' || v.presentation === 'transverse' || p.gravidity > 4);
      return {
        triggered,
        message: 'Previous Caesarean Section combined with malpresentation or grand multiparity.',
        finding: 'High Obstetric Risk (Previous CS + Complication)',
        intervention: 'Schedule elective Caesarean section at 38 weeks. Strictly refer to secondary health facility for ANC and delivery.'
      };
    }
  },
  {
    id: 'H5_GRAND_MULTIPARITY',
    name: 'Grand Multiparity',
    evaluate: (p) => {
      const triggered = p.gravidity >= 5;
      return {
        triggered,
        message: `High gravidity (${p.gravidity}). Patient is a grand multipara.`,
        finding: `Grand Multiparity (Gravidity: ${p.gravidity})`,
        intervention: 'Counsel on high risk of postpartum hemorrhage (PPH) and uterine atony. Plan for delivery at a facility with active management of third stage.'
      };
    }
  },
  {
    id: 'H6_PREVIOUS_STILLBIRTH_PPH',
    name: 'Bad Obstetric History',
    evaluate: (p) => {
      const triggered = p.previousStillbirth || p.previousPPH;
      const causes = [];
      if (p.previousStillbirth) causes.push('previous stillbirth');
      if (p.previousPPH) causes.push('previous postpartum hemorrhage');
      return {
        triggered,
        message: `Significant history of maternal/neonatal complications: ${causes.join(' and ')}.`,
        finding: `Bad Obstetric History (${causes.join(', ')})`,
        intervention: 'Initiate prophylactic active management of the third stage of labor (AMTSL) and refer for specialist-led delivery plan.'
      };
    }
  }
];

export const MODERATE_RISK_RULES: Array<{
  id: string;
  name: string;
  evaluate: (patient: Patient, visit: Partial<Visit>) => RuleResult;
}> = [
  {
    id: 'M1_MODERATE_ANAEMIA',
    name: 'Moderate Anaemia',
    evaluate: (_, v) => {
      const hb = v.hb || 0;
      const triggered = hb >= 7 && hb < 11;
      return {
        triggered,
        message: `Haemoglobin level indicates moderate anaemia: ${hb} g/dL.`,
        finding: `Moderate Anaemia (Hb: ${hb} g/dL)`,
        intervention: 'Prescribe therapeutic oral Iron (ferrous sulfate 200mg three times daily) and Folic Acid (5mg daily). Advise on rich dietary iron sources.'
      };
    }
  },
  {
    id: 'M2_CHRONIC_CONDITIONS',
    name: 'Co-existing Medical Condition',
    evaluate: (_, v) => {
      const h = v.history;
      const triggered = !!(h?.diabetes || h?.hiv || h?.malaria || h?.sickleCell || h?.tuberculosis);
      const conditions = [];
      if (h?.diabetes) conditions.push('Diabetes');
      if (h?.hiv) conditions.push('HIV');
      if (h?.malaria) conditions.push('Malaria');
      if (h?.sickleCell) conditions.push('Sickle Cell');
      if (h?.tuberculosis) conditions.push('Tuberculosis');
      return {
        triggered,
        message: `Patient has active co-existing chronic conditions: ${conditions.join(', ')}.`,
        finding: `Co-morbidities (${conditions.join(', ')})`,
        intervention: 'Coordinate care with specific disease programs (ART for HIV, DOTS for TB, Glycemic control for Diabetes). Ensure routine antimalarial IPTp-SP.'
      };
    }
  },
  {
    id: 'M3_ADOLESCENT_OR_OLDER_AGE',
    name: 'Maternal Age Extremes',
    evaluate: (p) => {
      const triggered = p.age < 18 || p.age > 35;
      const reason = p.age < 18 ? 'Adolescent pregnancy' : 'Advanced maternal age';
      return {
        triggered,
        message: `${reason} (${p.age} years old) carries elevated baseline risks.`,
        finding: `Age Risk (${p.age} years old)`,
        intervention: 'Provide specialized nutritional guidance, screen more frequently for preeclampsia, and monitor fetal growth closely.'
      };
    }
  },
  {
    id: 'M4_MULTIPLE_PREGNANCY',
    name: 'Multiple Pregnancy',
    evaluate: (_, v) => {
      const triggered = !!v.history?.multiplePregnancy;
      return {
        triggered,
        message: 'Patient is carrying a twin/multiple pregnancy.',
        finding: 'Multiple Pregnancy (Twins+)',
        intervention: 'Refer for baseline obstetric scan. Monitor fetal growth, cervix length, and plan for skilled delivery at a referral facility.'
      };
    }
  },
  {
    id: 'M5_URINE_GLUCOSE',
    name: 'Glycosuria',
    evaluate: (_, v) => {
      const triggered = v.urineGlucose !== undefined && v.urineGlucose !== 'negative';
      return {
        triggered,
        message: `Urine glucose detected: ${v.urineGlucose || 'unknown'} (Risk of Gestational Diabetes).`,
        finding: `Glycosuria (${v.urineGlucose || 'positive'})`,
        intervention: 'Order 75g Oral Glucose Tolerance Test (OGTT), counsel on sugar intake restrictions, and monitor fetal weight for macrosomia.'
      };
    }
  },
  {
    id: 'M6_PREV_PREECLAMPSIA',
    name: 'History of Preeclampsia',
    evaluate: (_, v) => {
      const triggered = !!v.history?.previousPreeclampsia;
      return {
        triggered,
        message: 'Patient has a history of preeclampsia in a prior pregnancy.',
        finding: 'History of Preeclampsia',
        intervention: 'Initiate low-dose Aspirin (75-150mg daily) starting before 16 weeks of gestation, and monitor BP very carefully.'
      };
    }
  }
];

/**
 * Deterministic rules evaluator
 */
export function evaluateRisk(patient: Patient, visit: Partial<Visit>): AssessmentResult {
  const triggeredRules: string[] = [];
  const clinicalFindings: string[] = [];
  const recommendedInterventions: string[] = [];
  let riskCategory: RiskLevel = 'low';

  // Evaluate Emergency Rules
  for (const rule of EMERGENCY_RULES) {
    const result = rule.evaluate(patient, visit);
    if (result.triggered) {
      triggeredRules.push(`[EMERGENCY] ${rule.name}: ${result.message}`);
      clinicalFindings.push(result.finding);
      recommendedInterventions.push(result.intervention);
      riskCategory = 'emergency';
    }
  }

  // If not emergency, evaluate High Risk
  if (riskCategory !== 'emergency') {
    for (const rule of HIGH_RISK_RULES) {
      const result = rule.evaluate(patient, visit);
      if (result.triggered) {
        triggeredRules.push(`[HIGH RISK] ${rule.name}: ${result.message}`);
        clinicalFindings.push(result.finding);
        recommendedInterventions.push(result.intervention);
        riskCategory = 'high';
      }
    }
  }

  // If not high or emergency, evaluate Moderate Risk
  if (riskCategory !== 'emergency' && riskCategory !== 'high') {
    for (const rule of MODERATE_RISK_RULES) {
      const result = rule.evaluate(patient, visit);
      if (result.triggered) {
        triggeredRules.push(`[MODERATE RISK] ${rule.name}: ${result.message}`);
        clinicalFindings.push(result.finding);
        recommendedInterventions.push(result.intervention);
        riskCategory = 'moderate';
      }
    }
  }

  // Default findings & interventions for low-risk
  if (riskCategory === 'low') {
    clinicalFindings.push('Routine healthy pregnancy signs.');
    recommendedInterventions.push('Continue standard WHO ANC plan (8 contacts). Advise on nutrition, routine iron/folate supplementation, and insecticide-treated nets (ITNs).');
  }

  // Determine follow-up date based on Risk Level and current Gestational Age
  // Standard WHO schedule or specialized intervals:
  let followUpWeeks = 4;
  if (riskCategory === 'emergency') {
    followUpWeeks = 0; // Immediate referral
  } else if (riskCategory === 'high') {
    followUpWeeks = 1; // 1 week follow up or immediate refer
  } else if (riskCategory === 'moderate') {
    followUpWeeks = 2; // 2 weeks follow up
  } else {
    // Low risk standard interval
    const ga = visit.gestationalAge || patient.gestationalAge || 12;
    if (ga >= 36) {
      followUpWeeks = 1;
    } else if (ga >= 28) {
      followUpWeeks = 2;
    } else {
      followUpWeeks = 4;
    }
  }

  const referralNeeded = riskCategory === 'high' || riskCategory === 'emergency';

  const today = new Date();
  const followUp = new Date(today.getTime() + followUpWeeks * 7 * 24 * 60 * 60 * 1000);
  const followUpDateStr = riskCategory === 'emergency' 
    ? 'IMMEDIATE REFERRAL' 
    : followUp.toISOString().split('T')[0];

  // ==========================================
  // OPTIONAL MACHINE LEARNING (PLACEHOLDER)
  // ==========================================
  // The model predicts risk probability, returns a confidence score, but NEVER overrides deterministic rules.
  // We simulate a regression-style neural network prediction based on input triggers:
  let scoreSum = 0;
  if (visit.systolic && visit.systolic > 130) scoreSum += 0.3;
  if (visit.diastolic && visit.diastolic > 85) scoreSum += 0.3;
  if (visit.hb && visit.hb < 10) scoreSum += 0.25;
  if (visit.urineProtein && visit.urineProtein !== 'negative') scoreSum += 0.2;
  if (visit.symptoms?.headache) scoreSum += 0.15;
  if (visit.symptoms?.bleeding) scoreSum += 0.4;
  if (visit.symptoms?.convulsions) scoreSum += 0.5;
  if (patient.age < 18 || patient.age > 35) scoreSum += 0.1;
  if (patient.gravidity >= 5) scoreSum += 0.15;
  if (patient.previousCS) scoreSum += 0.15;

  const mlProbability = Math.min(0.99, Math.max(0.05, scoreSum));
  const mlConfidence = 0.85 + Math.random() * 0.10; // High confidence for our simulated rule network

  return {
    riskCategory,
    triggeredRules,
    clinicalFindings,
    recommendedInterventions,
    referralNeeded,
    followUpDate: followUpDateStr,
    mlProbability: parseFloat(mlProbability.toFixed(2)),
    mlConfidence: parseFloat(mlConfidence.toFixed(2))
  };
}

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { 
  Plus, 
  Activity, 
  Database, 
  Wifi, 
  WifiOff, 
  Building, 
  UserCircle2, 
  RefreshCw,
  Award
} from 'lucide-react';
import { Patient, Visit, UserRole } from './types';
import { evaluateRisk } from './lib/riskEngine';
import DashboardView from './components/DashboardView';
import PatientDetails from './components/PatientDetails';
import RegistrationForm from './components/RegistrationForm';
import VisitForm from './components/VisitForm';
import ReferralPrintout from './components/ReferralPrintout';

const DEFAULT_PATIENTS: Patient[] = [
  {
    id: 'PAT-2026-001',
    name: 'Amina Bello',
    age: 38,
    phone: '08031234567',
    lga: 'Bwari',
    state: 'FCT',
    facility: 'Bwari Township PHC',
    gravidity: 5,
    parity: 4,
    edd: '2026-10-15',
    gestationalAge: 28,
    previousCS: false,
    previousStillbirth: false,
    previousPPH: true,
    createdAt: '2026-05-10T10:00:00.000Z'
  },
  {
    id: 'PAT-2026-002',
    name: 'Chioma Okafor',
    age: 29,
    phone: '08059876543',
    lga: 'Alimosho',
    state: 'Lagos',
    facility: 'Iyana Ipaja Primary Clinic',
    gravidity: 1,
    parity: 0,
    edd: '2026-09-02',
    gestationalAge: 34,
    previousCS: false,
    previousStillbirth: false,
    previousPPH: false,
    createdAt: '2026-06-15T09:30:00.000Z'
  },
  {
    id: 'PAT-2026-003',
    name: 'Comfort Ibrahim',
    age: 24,
    phone: '09012345678',
    lga: 'Gwagwalada',
    state: 'FCT',
    facility: 'Gwagwalada Township Health Centre',
    gravidity: 2,
    parity: 1,
    edd: '2026-11-20',
    gestationalAge: 23,
    previousCS: false,
    previousStillbirth: false,
    previousPPH: false,
    createdAt: '2026-07-01T11:15:00.000Z'
  }
];

const DEFAULT_VISITS: Visit[] = [
  {
    id: 'VIS-2026-101',
    patientId: 'PAT-2026-002',
    date: '2026-07-15',
    gestationalAge: 33,
    systolic: 154,
    diastolic: 96,
    weight: 78.5,
    height: 165,
    bmi: 28.8,
    temperature: 36.8,
    pulse: 88,
    respRate: 18,
    hb: 10.2,
    urineProtein: '2+',
    urineGlucose: 'negative',
    bloodGroup: 'O',
    rhesus: '+',
    fundalHeight: 32,
    fetalHeartRate: 142,
    fetalMovement: 'normal',
    presentation: 'cephalic',
    symptoms: {
      headache: true,
      blurredVision: true,
      swelling: true,
      bleeding: false,
      convulsions: false,
      fever: false,
      reducedFetalMovement: false,
      abdominalPain: false,
      vomiting: false
    },
    history: {
      hypertension: false,
      diabetes: false,
      hiv: false,
      malaria: false,
      sickleCell: false,
      tuberculosis: false,
      multiplePregnancy: false,
      smoking: false,
      alcohol: false,
      drugUse: false,
      previousPreeclampsia: false
    },
    riskCategory: 'high',
    triggeredRules: [
      '[HIGH RISK] Suspected Preeclampsia: Elevated BP (154/96 mmHg) with proteinuria (2+) or severe neurological symptoms (headache, vision changes).'
    ],
    clinicalFindings: [
      'Suspected Preeclampsia (BP: 154/96 mmHg, Protein: 2+)'
    ],
    recommendedInterventions: [
      'Admit to facility, initiate MgSO4 prophylaxis protocol, administer oral Methyldopa 250mg, and refer to obstetrician.'
    ],
    referralNeeded: true,
    referralFacility: 'General Hospital Garki',
    followUpDate: '2026-07-22',
    mlProbability: 0.88,
    mlConfidence: 0.94,
    explanation: 'This patient was classified as High Risk because blood pressure exceeded WHO thresholds (154/96 mmHg), she exhibits marked proteinuria (2+), and presents with severe preeclampsia warning signs including headache and blurred vision.',
    clinicianRole: 'midwife',
    clinicianName: 'Sister Grace Nwosu',
    syncStatus: 'synced'
  },
  {
    id: 'VIS-2026-102',
    patientId: 'PAT-2026-003',
    date: '2026-07-10',
    gestationalAge: 21,
    systolic: 112,
    diastolic: 74,
    weight: 62.0,
    height: 160,
    bmi: 24.2,
    temperature: 36.5,
    pulse: 78,
    respRate: 16,
    hb: 11.5,
    urineProtein: 'negative',
    urineGlucose: 'negative',
    bloodGroup: 'B',
    rhesus: '+',
    fundalHeight: 20,
    fetalHeartRate: 145,
    fetalMovement: 'normal',
    presentation: 'unknown',
    symptoms: {
      headache: false,
      blurredVision: false,
      swelling: false,
      bleeding: false,
      convulsions: false,
      fever: false,
      reducedFetalMovement: false,
      abdominalPain: false,
      vomiting: false
    },
    history: {
      hypertension: false,
      diabetes: false,
      hiv: false,
      malaria: false,
      sickleCell: false,
      tuberculosis: false,
      multiplePregnancy: false,
      smoking: false,
      alcohol: false,
      drugUse: false,
      previousPreeclampsia: false
    },
    riskCategory: 'low',
    triggeredRules: [],
    clinicalFindings: [
      'Routine healthy pregnancy signs.'
    ],
    recommendedInterventions: [
      'Continue standard WHO ANC plan (8 contacts). Advise on nutrition, routine iron/folate supplementation, and insecticide-treated nets (ITNs).'
    ],
    referralNeeded: false,
    followUpDate: '2026-08-07',
    mlProbability: 0.08,
    mlConfidence: 0.91,
    explanation: 'This patient is classified as Low Risk because her clinical vitals, laboratory tests, and symptoms are completely within normal WHO guidelines, with a healthy haemoglobin level and normal blood pressure.',
    clinicianRole: 'chew',
    clinicianName: 'CHEW Joshua Adamu',
    syncStatus: 'synced'
  }
];

export default function App() {
  const [view, setView] = React.useState<'dashboard' | 'register_patient' | 'record_visit' | 'patient_details' | 'referral_print'>('dashboard');
  const [role, setRole] = React.useState<UserRole>('midwife');
  
  const [patients, setPatients] = React.useState<Patient[]>([]);
  const [visits, setVisits] = React.useState<Visit[]>([]);
  const [selectedPatientId, setSelectedPatientId] = React.useState<string | null>(null);
  const [printVisit, setPrintVisit] = React.useState<Visit | null>(null);
  
  const [isOnline, setIsOnline] = React.useState(navigator.onLine);
  const [isSyncing, setIsSyncing] = React.useState(false);

  // Load ledger from API / LocalStorage
  React.useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    initializeLedger();

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const initializeLedger = async () => {
    // 1. Get from localStorage or Seed
    let localPatients = JSON.parse(localStorage.getItem('maternite_patients') || '[]');
    let localVisits = JSON.parse(localStorage.getItem('maternite_visits') || '[]');

    if (localPatients.length === 0) {
      localStorage.setItem('maternite_patients', JSON.stringify(DEFAULT_PATIENTS));
      localPatients = DEFAULT_PATIENTS;
    }
    if (localVisits.length === 0) {
      localStorage.setItem('maternite_visits', JSON.stringify(DEFAULT_VISITS));
      localVisits = DEFAULT_VISITS;
    }

    setPatients(localPatients);
    setVisits(localVisits);

    // 2. Try to fetch fresh records from server (Full-stack mode)
    try {
      const pRes = await fetch('/api/patients');
      if (pRes.ok) {
        const serverPatients = await pRes.json();
        // Merge server and local storage
        const mergedPatients = mergePatientsList(localPatients, serverPatients);
        setPatients(mergedPatients);
        localStorage.setItem('maternite_patients', JSON.stringify(mergedPatients));
      }
    } catch (err) {
      console.log('Serving offline data, server unreachable.');
    }
  };

  const mergePatientsList = (local: Patient[], server: Patient[]): Patient[] => {
    const map = new Map<string, Patient>();
    server.forEach(p => map.set(p.id, p));
    local.forEach(p => {
      if (!map.has(p.id)) {
        map.set(p.id, p);
      }
    });
    return Array.from(map.values());
  };

  // Synchronize any pending records (Offline-First sync engine)
  const syncOfflineRecords = async () => {
    if (!isOnline) return;
    setIsSyncing(true);

    const localPatients: Patient[] = JSON.parse(localStorage.getItem('maternite_patients') || '[]');
    const localVisits: Visit[] = JSON.parse(localStorage.getItem('maternite_visits') || '[]');

    const pendingPatients = localPatients.filter((p: any) => p.syncStatus === 'pending');
    const pendingVisits = localVisits.filter(v => v.syncStatus === 'pending');

    if (pendingPatients.length === 0 && pendingVisits.length === 0) {
      setIsSyncing(false);
      return;
    }

    try {
      const res = await fetch('/api/sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          patients: pendingPatients,
          visits: pendingVisits
        })
      });

      if (res.ok) {
        // Mark all as synced
        const syncedPatients = localPatients.map((p: any) => ({ ...p, syncStatus: 'synced' }));
        const syncedVisits = localVisits.map(v => ({ ...v, syncStatus: 'synced' }));

        localStorage.setItem('maternite_patients', JSON.stringify(syncedPatients));
        localStorage.setItem('maternite_visits', JSON.stringify(syncedVisits));
        
        setPatients(syncedPatients);
        setVisits(syncedVisits);
        console.log('Offline records synchronized successfully.');
      }
    } catch (err) {
      console.warn('Sync failed:', err);
    } finally {
      setIsSyncing(false);
    }
  };

  // Perform full dashboard statistics calculations (works online & offline)
  const dashboardStats = React.useMemo(() => {
    const totalPatients = patients.length;
    const totalVisits = visits.length;

    const riskDistribution = {
      low: 0,
      moderate: 0,
      high: 0,
      emergency: 0
    };

    let totalHb = 0;
    let countHb = 0;
    let totalSystolic = 0;
    let totalDiastolic = 0;
    let countBP = 0;
    let referralsCount = 0;

    visits.forEach(v => {
      riskDistribution[v.riskCategory]++;
      if (v.hb) {
        totalHb += v.hb;
        countHb++;
      }
      if (v.systolic && v.diastolic) {
        totalSystolic += v.systolic;
        totalDiastolic += v.diastolic;
        countBP++;
      }
      if (v.referralNeeded) {
        referralsCount++;
      }
    });

    const referralRate = totalVisits > 0 ? (referralsCount / totalVisits) * 100 : 0;
    const avgHb = countHb > 0 ? totalHb / countHb : 0;
    const avgBPSystolic = countBP > 0 ? totalSystolic / countBP : 0;
    const avgBPDiastolic = countBP > 0 ? totalDiastolic / countBP : 0;

    // Monthly trends (seed for graph)
    const monthlyTrends = [
      { month: 'Feb', visits: 12, low: 8, moderate: 3, high: 1, emergency: 0 },
      { month: 'Mar', visits: 18, low: 11, moderate: 5, high: 2, emergency: 0 },
      { month: 'Apr', visits: 25, low: 16, moderate: 6, high: 2, emergency: 1 },
      { month: 'May', visits: 32, low: 22, moderate: 7, high: 3, emergency: 0 },
      { month: 'Jun', visits: 45, low: 31, moderate: 9, high: 4, emergency: 1 },
      { month: 'Jul', visits: totalVisits, low: riskDistribution.low, moderate: riskDistribution.moderate, high: riskDistribution.high, emergency: riskDistribution.emergency }
    ];

    // Facility Comparisons
    const uniqueFacilities = Array.from(new Set(patients.map(p => p.facility)));
    const facilityStatsList = uniqueFacilities.map((fac, idx) => {
      const facPatients = patients.filter(p => p.facility === fac);
      const facPatientIds = facPatients.map(p => p.id);
      const facVisits = visits.filter(v => facPatientIds.includes(v.patientId));
      
      const dist = { low: 0, moderate: 0, high: 0, emergency: 0 };
      let hbSum = 0;
      let hbCount = 0;
      let refCount = 0;
      
      facVisits.forEach(v => {
        dist[v.riskCategory]++;
        if (v.hb) {
          hbSum += v.hb;
          hbCount++;
        }
        if (v.referralNeeded) {
          refCount++;
        }
      });

      return {
        id: `FAC-00${idx + 1}`,
        name: fac,
        totalPatients: facPatients.length,
        totalVisits: facVisits.length,
        riskDistribution: dist,
        referralRate: facVisits.length > 0 ? Math.round((refCount / facVisits.length) * 100) : 0,
        avgHb: hbCount > 0 ? parseFloat((hbSum / hbCount).toFixed(1)) : 11.0
      };
    });

    return {
      totalPatients,
      totalVisits,
      riskDistribution,
      referralRate: parseFloat(referralRate.toFixed(1)),
      avgHb: parseFloat(avgHb.toFixed(1)),
      avgBPSystolic: Math.round(avgBPSystolic),
      avgBPDiastolic: Math.round(avgBPDiastolic),
      monthlyTrends,
      facilityStats: facilityStatsList,
      referralCompletionRate: 85
    };
  }, [patients, visits]);

  // Handle registering a patient
  const handleRegisterPatient = async (pData: any) => {
    const id = `PAT-2026-${String(patients.length + 1).padStart(3, '0')}`;
    const newPatient: Patient = {
      ...pData,
      id,
      createdAt: new Date().toISOString(),
      syncStatus: isOnline ? 'synced' : 'pending'
    };

    // Update state & Local Storage immediately (Offline-First)
    const updatedPatients = [newPatient, ...patients];
    setPatients(updatedPatients);
    localStorage.setItem('maternite_patients', JSON.stringify(updatedPatients));

    if (isOnline) {
      try {
        await fetch('/api/patients', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(newPatient)
        });
      } catch (err) {
        console.warn('Silent save online failed, marked for sync.');
        // Update local to show pending sync
        newPatient.syncStatus = 'pending';
        localStorage.setItem('maternite_patients', JSON.stringify(updatedPatients));
      }
    }

    setView('dashboard');
  };

  // Handle saving a visit (Online + offline routing)
  const handleRecordVisit = async (vData: any) => {
    const visitId = `VIS-2026-${String(visits.length + 101).padStart(3, '0')}`;
    
    // Evaluate risk deterministically first
    const activePatient = patients.find(p => p.id === selectedPatientId);
    if (!activePatient) return;

    const assessmentResult = evaluateRisk(activePatient, vData);

    const newVisit: Visit = {
      ...vData,
      id: visitId,
      patientId: selectedPatientId!,
      date: new Date().toISOString().split('T')[0],
      riskCategory: assessmentResult.riskCategory,
      triggeredRules: assessmentResult.triggeredRules,
      clinicalFindings: assessmentResult.clinicalFindings,
      recommendedInterventions: assessmentResult.recommendedInterventions,
      referralNeeded: assessmentResult.referralNeeded,
      followUpDate: assessmentResult.followUpDate,
      mlProbability: assessmentResult.mlProbability,
      mlConfidence: assessmentResult.mlConfidence,
      syncStatus: isOnline ? 'synced' : 'pending',
      explanation: `This patient was classified as ${assessmentResult.riskCategory.toUpperCase()} because: ${assessmentResult.clinicalFindings.join(', ')}.`
    };

    // Update state & local ledger immediately (Offline-First)
    const updatedVisits = [newVisit, ...visits];
    setVisits(updatedVisits);
    localStorage.setItem('maternite_visits', JSON.stringify(updatedVisits));

    setView('patient_details');

    if (isOnline) {
      try {
        const response = await fetch('/api/visits', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(newVisit)
        });
        if (response.ok) {
          const freshVisit = await response.json();
          // Update the localized record with server's generated Gemini narrative explanation
          const refreshedVisits = updatedVisits.map(v => v.id === visitId ? freshVisit : v);
          setVisits(refreshedVisits);
          localStorage.setItem('maternite_visits', JSON.stringify(refreshedVisits));
        }
      } catch (err) {
        console.warn('Saving visit to server failed, kept local.');
      }
    }
  };

  const activePatientObj = patients.find(p => p.id === selectedPatientId);
  const activePatientVisits = visits.filter(v => v.patientId === selectedPatientId);

  const pendingSyncCount = patients.filter((p: any) => p.syncStatus === 'pending').length +
                           visits.filter(v => v.syncStatus === 'pending').length;

  return (
    <div className="min-h-screen bg-slate-50/40 flex flex-col font-sans text-slate-800 antialiased" id="maternite-app-root">
      
      {/* Clinician Top Command Bar (Universal Header) */}
      <header className="bg-slate-900 text-white shadow-[0_4px_20px_rgba(0,0,0,0.08)] border-b border-slate-800 sticky top-0 z-50 print:hidden transition-all duration-300">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          
          {/* Left branding */}
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 bg-gradient-to-tr from-teal-400 to-teal-500 rounded-xl flex items-center justify-center text-slate-950 font-black tracking-tight text-lg shadow-[0_2px_10px_rgba(20,184,166,0.3)] font-display">
              M
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-sm font-bold uppercase tracking-wider text-teal-400 font-display">Maternite</span>
                <span className="text-[9px] bg-slate-800 text-slate-300 px-2 py-0.5 rounded font-bold font-mono border border-slate-700/50">v1.2.0</span>
              </div>
              <p className="text-[10px] text-slate-400 font-medium">Nigerian PHC Maternal Risk Stratification Scheme</p>
            </div>
          </div>

          {/* Center/Right Sync & Role Commands */}
          <div className="flex flex-wrap items-center gap-3 self-end sm:self-auto">
            
            {/* Connectivity status indicator */}
            <div className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-bold border transition-all duration-300 shadow-sm
              ${isOnline ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400' : 'bg-red-500/10 border-red-500/20 text-red-400'}`}>
              {isOnline ? <Wifi size={12} className="text-emerald-400" /> : <WifiOff size={12} className="text-red-400" />}
              <span>{isOnline ? 'Connected' : 'Offline Mode'}</span>
            </div>

            {/* Offline-First sync button */}
            {pendingSyncCount > 0 && (
              <button
                onClick={syncOfflineRecords}
                disabled={isSyncing || !isOnline}
                className={`flex items-center gap-1.5 px-3.5 py-1 bg-gradient-to-r from-teal-400 to-teal-500 hover:from-teal-500 hover:to-teal-600 disabled:from-slate-800 disabled:to-slate-800 text-slate-950 disabled:text-slate-500 rounded-full text-[10px] font-bold transition-all duration-300 shadow-sm cursor-pointer hover:scale-[1.02] active:scale-95`}
              >
                <RefreshCw size={12} className={isSyncing ? 'animate-spin' : ''} />
                <span>Sync Ledger ({pendingSyncCount})</span>
              </button>
            )}

            {/* Role Simulation Switcher */}
            <div className="flex items-center gap-1.5 bg-slate-800 p-1 rounded-xl border border-slate-700 shadow-sm">
              <UserCircle2 size={14} className="text-slate-400 ml-1.5" />
              <select
                value={role}
                onChange={(e) => setRole(e.target.value as UserRole)}
                className="text-[10px] font-bold bg-transparent text-white border-none focus:outline-none focus:ring-0 pr-8 pl-1 text-teal-300 cursor-pointer"
              >
                <option value="midwife" className="bg-slate-900 text-white">Sister Midwife</option>
                <option value="chew" className="bg-slate-900 text-white">CHEW Officer</option>
                <option value="admin" className="bg-slate-900 text-white">Facility Admin</option>
                <option value="district_officer" className="bg-slate-900 text-white">District Officer</option>
                <option value="state_manager" className="bg-slate-900 text-white">State Manager</option>
              </select>
            </div>

          </div>
        </div>
      </header>

      {/* Role Announcement Bar */}
      <div className="bg-teal-500 text-slate-950 text-[11px] font-bold px-4 py-1.5 flex items-center justify-between shadow-md print:hidden transition-all duration-300">
        <div className="max-w-7xl mx-auto w-full flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <Award size={14} className="text-slate-900" />
            <span className="font-display">Active Session Profile: <strong className="uppercase tracking-wider font-extrabold">{role.replace('_', ' ')}</strong></span>
          </div>
          <span className="text-[10px] font-mono tracking-wider opacity-90">Primary Care Command • Nigeria</span>
        </div>
      </div>

      {/* Main body content container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        
        {view === 'dashboard' && (
          <div className="space-y-6">
            
            {/* Quick Actions Panel */}
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between bg-white p-5 rounded-2xl border border-slate-200/60 shadow-[0_2px_12px_rgba(0,0,0,0.03)] gap-4 print:hidden hover:shadow-[0_4px_16px_rgba(0,0,0,0.05)] transition-all duration-300">
              <div>
                <h3 className="text-sm font-bold text-slate-800 font-display">Antenatal Clinical Workdesk</h3>
                <p className="text-xs text-slate-400 mt-0.5">Register mothers, record vitals, and generate instant clinical explanations.</p>
              </div>
              
              <div className="flex items-center gap-3">
                <button
                  onClick={() => setView('register_patient')}
                  className="px-4.5 py-2.5 bg-teal-600 hover:bg-teal-700 text-white font-semibold rounded-xl text-xs flex items-center gap-1.5 transition-all duration-300 shadow-md shadow-teal-600/10 hover:shadow-teal-700/20 cursor-pointer hover:scale-[1.02] active:scale-[0.98]"
                >
                  <Plus size={14} className="stroke-[3px]" /> Register New Patient
                </button>
              </div>
            </div>

            <DashboardView 
              stats={dashboardStats} 
              patients={patients} 
              visits={visits}
              onSelectPatient={(id) => {
                setSelectedPatientId(id);
                setView('patient_details');
              }}
              role={role}
            />
          </div>
        )}

        {view === 'register_patient' && (
          <RegistrationForm 
            onBack={() => setView('dashboard')} 
            onSubmit={handleRegisterPatient}
          />
        )}

        {view === 'record_visit' && activePatientObj && (
          <VisitForm 
            patient={activePatientObj}
            onBack={() => setView('patient_details')}
            onSubmit={handleRecordVisit}
            role={role}
          />
        )}

        {view === 'patient_details' && activePatientObj && (
          <PatientDetails 
            patient={activePatientObj}
            visits={activePatientVisits}
            onBack={() => setView('dashboard')}
            onNewVisit={() => setView('record_visit')}
            onPrintReferral={(v) => {
              setPrintVisit(v);
              setView('referral_print');
            }}
          />
        )}

        {view === 'referral_print' && activePatientObj && printVisit && (
          <ReferralPrintout 
            patient={activePatientObj}
            visit={printVisit}
            onBack={() => setView('patient_details')}
          />
        )}

      </main>

      {/* Clinical footer */}
      <footer className="bg-white border-t border-slate-100 py-6 text-center text-xs text-slate-400 mt-12 print:hidden">
        <p className="font-semibold text-slate-500">Maternite • AI-Assisted Maternal and Neonatal Antenatal Risk Stratification Scheme</p>
        <p className="mt-1 leading-normal">Developed in strict adherence to WHO Clinical Guidelines and Nigeria Maternal and Child Health Protocols.<br />All LLM components are strictly server-bound, safe, and explanatory.</p>
        <p className="text-[10px] font-mono text-slate-300 mt-3">Ref: FCT-PRIMARY-HEALTH-CARE-LEDGER-2026</p>
      </footer>

    </div>
  );
}

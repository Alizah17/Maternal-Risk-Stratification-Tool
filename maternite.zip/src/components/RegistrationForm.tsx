/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { ArrowLeft, User, Phone, Map, Building2, Calendar, FilePlus } from 'lucide-react';

interface RegistrationFormProps {
  onBack: () => void;
  onSubmit: (patientData: any) => void;
}

export default function RegistrationForm({ onBack, onSubmit }: RegistrationFormProps) {
  const [formData, setFormData] = React.useState({
    name: '',
    age: '',
    phone: '',
    lga: 'Bwari',
    state: 'FCT',
    facility: 'Bwari Township PHC',
    gravidity: '1',
    parity: '0',
    edd: '',
    gestationalAge: '12',
    previousCS: false,
    previousStillbirth: false,
    previousPPH: false
  });

  const [errors, setErrors] = React.useState<Record<string, string>>({});

  const LGAS = [
    { name: 'Bwari', state: 'FCT', facility: 'Bwari Township PHC' },
    { name: 'Gwagwalada', state: 'FCT', facility: 'Gwagwalada Township Health Centre' },
    { name: 'Kuje', state: 'FCT', facility: 'Kuje Comprehensive Clinic' },
    { name: 'Alimosho', state: 'Lagos', facility: 'Iyana Ipaja Primary Clinic' },
    { name: 'Kano Municipal', state: 'Kano', facility: 'Kano Township PHC' },
    { name: 'Maiduguri', state: 'Borno', facility: 'Bolori PHC Clinic' }
  ];

  const handleLgaChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const selectedLga = LGAS.find(l => l.name === e.target.value);
    if (selectedLga) {
      setFormData(prev => ({
        ...prev,
        lga: selectedLga.name,
        state: selectedLga.state,
        facility: selectedLga.facility
      }));
    }
  };

  // Naegele's rule for EDD from LMP (or user can input directly)
  const handleLmpChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const lmpDateStr = e.target.value;
    if (!lmpDateStr) return;

    const lmpDate = new Date(lmpDateStr);
    
    // Add 280 days (9 months and 7 days)
    const eddDate = new Date(lmpDate.getTime() + 280 * 24 * 60 * 60 * 1000);
    const eddStr = eddDate.toISOString().split('T')[0];

    // Calculate Gestational Age
    const diffTime = Math.abs(new Date().getTime() - lmpDate.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    const weeks = Math.min(42, Math.max(1, Math.floor(diffDays / 7)));

    setFormData(prev => ({
      ...prev,
      edd: eddStr,
      gestationalAge: String(weeks)
    }));
  };

  const validate = () => {
    const newErrors: Record<string, string> = {};
    if (!formData.name.trim()) newErrors.name = 'Full Name is required.';
    if (!formData.age) {
      newErrors.age = 'Age is required.';
    } else if (Number(formData.age) < 12 || Number(formData.age) > 55) {
      newErrors.age = 'Age must be a valid reproductive age (12 - 55).';
    }
    if (!formData.phone.trim()) {
      newErrors.phone = 'Phone Number is required.';
    } else if (!/^[0-9+]{10,14}$/.test(formData.phone.trim())) {
      newErrors.phone = 'Enter a valid Nigerian phone number (e.g., 08031234567).';
    }
    if (!formData.edd) newErrors.edd = 'Estimated Date of Delivery (EDD) is required.';
    
    const grav = Number(formData.gravidity);
    const par = Number(formData.parity);
    if (grav < 1) newErrors.gravidity = 'Gravidity must be at least 1.';
    if (par < 0) newErrors.parity = 'Parity cannot be negative.';
    if (par >= grav) newErrors.parity = 'Parity (previous births) must be less than Gravidity (total pregnancies).';

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validate()) {
      onSubmit({
        ...formData,
        age: Number(formData.age),
        gravidity: Number(formData.gravidity),
        parity: Number(formData.parity),
        gestationalAge: Number(formData.gestationalAge)
      });
    }
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200/60 shadow-[0_2px_12px_rgba(0,0,0,0.03)] p-6 max-w-3xl mx-auto space-y-6" id="registration-form-root">
      
      {/* Header */}
      <div className="flex items-center justify-between pb-4 border-b border-slate-100">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-teal-50 text-teal-600 rounded-xl">
            <User size={20} className="stroke-[2.5]" />
          </div>
          <div>
            <h2 className="text-base font-black text-slate-800 font-display tracking-tight leading-none">New Maternal Registration</h2>
            <p className="text-xs text-slate-400 mt-1 font-semibold">Add maternal bio-parameters to the facility ledger</p>
          </div>
        </div>
        <button 
          onClick={onBack}
          className="text-xs font-bold text-slate-500 hover:text-slate-800 flex items-center gap-1.5 transition-all duration-200 hover:scale-[1.02] active:scale-95 cursor-pointer"
        >
          <ArrowLeft size={14} /> Back
        </button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6 text-xs font-medium">
        
        {/* Sub-grid 1: Biographic */}
        <div className="space-y-4">
          <h3 className="font-black text-slate-400 text-[10px] uppercase tracking-wider font-display">1. Biographic Details</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            
            {/* Full Name */}
            <div className="space-y-1.5">
              <label className="font-bold text-slate-700 flex items-center gap-1 font-display">Full Name <span className="text-red-500">*</span></label>
              <div className="relative font-semibold">
                <User className="absolute left-3.5 top-3 text-slate-400" size={13} />
                <input 
                  type="text" 
                  placeholder="E.g., Comfort Ibrahim"
                  value={formData.name}
                  onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                  className={`w-full pl-9 pr-3 py-2.5 bg-slate-50/50 border rounded-xl focus:outline-none focus:ring-1 focus:ring-teal-500 focus:bg-white focus:border-teal-500 transition-all duration-200 ${errors.name ? 'border-red-300 bg-red-50/10' : 'border-slate-200'}`}
                />
              </div>
              {errors.name && <p className="text-[10px] text-red-500 font-bold">{errors.name}</p>}
            </div>

            {/* Maternal Age */}
            <div className="space-y-1.5">
              <label className="font-bold text-slate-700 font-display">Maternal Age <span className="text-red-500">*</span></label>
              <input 
                type="number" 
                placeholder="E.g., 24"
                value={formData.age}
                onChange={(e) => setFormData(prev => ({ ...prev, age: e.target.value }))}
                className={`w-full px-3 py-2.5 bg-slate-50/50 border rounded-xl focus:outline-none focus:ring-1 focus:ring-teal-500 focus:bg-white focus:border-teal-500 transition-all duration-200 font-semibold font-mono ${errors.age ? 'border-red-300 bg-red-50/10' : 'border-slate-200'}`}
              />
              {errors.age && <p className="text-[10px] text-red-500 font-bold">{errors.age}</p>}
            </div>

            {/* Phone Number */}
            <div className="space-y-1.5">
              <label className="font-bold text-slate-700 flex items-center gap-1 font-display">Primary Phone Number <span className="text-red-500">*</span></label>
              <div className="relative font-semibold">
                <Phone className="absolute left-3.5 top-3 text-slate-400" size={13} />
                <input 
                  type="text" 
                  placeholder="E.g., 08031234567"
                  value={formData.phone}
                  onChange={(e) => setFormData(prev => ({ ...prev, phone: e.target.value }))}
                  className={`w-full pl-9 pr-3 py-2.5 bg-slate-50/50 border rounded-xl focus:outline-none focus:ring-1 focus:ring-teal-500 focus:bg-white focus:border-teal-500 transition-all duration-200 font-mono ${errors.phone ? 'border-red-300 bg-red-50/10' : 'border-slate-200'}`}
                />
              </div>
              {errors.phone && <p className="text-[10px] text-red-500 font-bold">{errors.phone}</p>}
            </div>

            {/* LGA / Location Selector */}
            <div className="space-y-1.5">
              <label className="font-bold text-slate-700 flex items-center gap-1 font-display"><Map size={12} className="text-slate-400" /> LGA & primary care facility mapping</label>
              <select
                value={formData.lga}
                onChange={handleLgaChange}
                className="w-full px-3 py-2.5 bg-slate-50/50 border border-slate-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-teal-500 focus:bg-white focus:border-teal-500 transition-all duration-200 font-semibold cursor-pointer text-slate-700"
              >
                {LGAS.map(lga => (
                  <option key={lga.name} value={lga.name}>{lga.name} ({lga.state})</option>
                ))}
              </select>
            </div>

            {/* Autoloaded State/Facility mapping */}
            <div className="space-y-1.5">
              <label className="font-bold text-slate-400 flex items-center gap-1 font-display"><Building2 size={12} /> Mapping state target</label>
              <input 
                type="text" 
                disabled 
                value={`${formData.facility} — ${formData.state} State`} 
                className="w-full px-3 py-2.5 bg-slate-100 border border-slate-200 text-slate-500 rounded-xl cursor-not-allowed font-bold"
              />
            </div>

          </div>
        </div>

        {/* Sub-grid 2: LMP to Gestational / EDD Calculator */}
        <div className="space-y-4 pt-4 border-t border-slate-150">
          <h3 className="font-black text-slate-400 text-[10px] uppercase tracking-wider flex items-center gap-1.5 font-display">
            <Calendar size={14} className="text-teal-600 stroke-[2.5]" /> 2. Gestational Age & Delivery Planning (Naegele's Rule)
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            
            {/* Last Menstrual Period LMP */}
            <div className="space-y-1.5 bg-teal-50/30 p-3 rounded-xl border border-teal-100/60 flex flex-col justify-between">
              <div>
                <label className="font-bold text-teal-850 font-display">LMP (Last Menstrual Period)</label>
                <input 
                  type="date" 
                  onChange={handleLmpChange}
                  className="w-full px-3 py-1.5 mt-1 bg-white border border-teal-200 text-teal-900 rounded-lg focus:outline-none focus:ring-1 focus:ring-teal-500 font-semibold font-mono"
                />
              </div>
              <span className="text-[9px] text-teal-600/90 block leading-tight mt-1.5 font-semibold">Calculates gestational age and EDD automatically.</span>
            </div>

            {/* Estimated Delivery Date */}
            <div className="space-y-1.5 pt-1.5">
              <label className="font-bold text-slate-700 font-display">Estimated Delivery Date (EDD) <span className="text-red-500">*</span></label>
              <input 
                type="date" 
                value={formData.edd}
                onChange={(e) => setFormData(prev => ({ ...prev, edd: e.target.value }))}
                className={`w-full px-3 py-2.5 bg-slate-50/50 border rounded-xl focus:outline-none focus:ring-1 focus:ring-teal-500 focus:bg-white focus:border-teal-500 transition-all duration-200 font-semibold font-mono ${errors.edd ? 'border-red-300 bg-red-50/10' : 'border-slate-200'}`}
              />
              {errors.edd && <p className="text-[10px] text-red-500 font-bold">{errors.edd}</p>}
            </div>

            {/* Gestational Age */}
            <div className="space-y-1.5 pt-1.5">
              <label className="font-bold text-slate-700 font-display">Gestational Age (Weeks)</label>
              <input 
                type="number" 
                min="1" 
                max="44"
                value={formData.gestationalAge}
                onChange={(e) => setFormData(prev => ({ ...prev, gestationalAge: e.target.value }))}
                className="w-full px-3 py-2.5 bg-slate-50/50 border border-slate-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-teal-500 focus:bg-white focus:border-teal-500 transition-all duration-200 font-bold font-mono"
              />
            </div>

          </div>
        </div>

        {/* Sub-grid 3: Obstetric History */}
        <div className="space-y-4 pt-4 border-t border-slate-150">
          <h3 className="font-black text-slate-400 text-[10px] uppercase tracking-wider font-display">3. Obstetric Ledger Profile</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            
            {/* Gravidity & Parity */}
            <div className="space-y-3 bg-slate-50/50 p-4 rounded-xl border border-slate-200/80">
              <span className="text-[10px] font-black text-slate-400 uppercase tracking-wider block font-display">Gravidity & Parity Ledger</span>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="font-bold text-slate-700">Gravidity</label>
                  <input 
                    type="number" 
                    min="1" 
                    value={formData.gravidity}
                    onChange={(e) => setFormData(prev => ({ ...prev, gravidity: e.target.value }))}
                    className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-teal-500 font-bold font-mono"
                  />
                  {errors.gravidity && <p className="text-[10px] text-red-500 font-bold">{errors.gravidity}</p>}
                </div>

                <div className="space-y-1.5">
                  <label className="font-bold text-slate-700">Parity</label>
                  <input 
                    type="number" 
                    min="0"
                    value={formData.parity}
                    onChange={(e) => setFormData(prev => ({ ...prev, parity: e.target.value }))}
                    className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-teal-500 font-bold font-mono"
                  />
                  {errors.parity && <p className="text-[10px] text-red-500 font-bold">{errors.parity}</p>}
                </div>
              </div>
              <span className="text-[10px] text-slate-400 font-semibold leading-relaxed block pt-1">
                Gravidity is the total number of pregnancies, and Parity is the number of births carried to viable gestational age (&gt; 24 weeks).
              </span>
            </div>

            {/* High risk historical checkmarks */}
            <div className="space-y-3 bg-red-50/15 p-4 rounded-xl border border-red-100/60">
              <span className="text-[10px] font-black text-red-800 uppercase tracking-wider block font-display">Bad Obstetric History Triggers</span>
              
              <div className="space-y-2.5 pt-1 text-slate-700 font-semibold">
                <label className="flex items-center gap-3 cursor-pointer select-none">
                  <input 
                    type="checkbox" 
                    checked={formData.previousCS}
                    onChange={(e) => setFormData(prev => ({ ...prev, previousCS: e.target.checked }))}
                    className="w-4 h-4 rounded border-slate-300 text-teal-600 focus:ring-teal-500 cursor-pointer"
                  />
                  <span>History of Previous Caesarean Section (CS)</span>
                </label>

                <label className="flex items-center gap-3 cursor-pointer select-none">
                  <input 
                    type="checkbox" 
                    checked={formData.previousStillbirth}
                    onChange={(e) => setFormData(prev => ({ ...prev, previousStillbirth: e.target.checked }))}
                    className="w-4 h-4 rounded border-slate-300 text-teal-600 focus:ring-teal-500 cursor-pointer"
                  />
                  <span>History of Previous Stillbirth</span>
                </label>

                <label className="flex items-center gap-3 cursor-pointer select-none">
                  <input 
                    type="checkbox" 
                    checked={formData.previousPPH}
                    onChange={(e) => setFormData(prev => ({ ...prev, previousPPH: e.target.checked }))}
                    className="w-4 h-4 rounded border-slate-300 text-teal-600 focus:ring-teal-500 cursor-pointer"
                  />
                  <span>History of Postpartum Haemorrhage (PPH)</span>
                </label>
              </div>
            </div>

          </div>
        </div>

        {/* Action Button */}
        <div className="pt-4 border-t border-slate-150 flex justify-end">
          <button 
            type="submit"
            className="px-5 py-3 bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-700 hover:to-emerald-700 text-white rounded-xl font-bold flex items-center gap-2 shadow-sm hover:shadow-md transition-all duration-200 hover:scale-[1.02] active:scale-95 cursor-pointer"
          >
            <FilePlus size={16} className="stroke-[2.5]" /> Register Maternal Record
          </button>
        </div>

      </form>
    </div>
  );
}

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { 
  Users, 
  Activity, 
  ShieldAlert, 
  ArrowRightLeft, 
  Droplet, 
  Heart, 
  TrendingUp, 
  FileText, 
  Building2, 
  Search,
  CheckCircle,
  FileDown
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  Legend, 
  AreaChart, 
  Area 
} from 'recharts';
import { Patient, Visit } from '../types';

interface DashboardStats {
  totalPatients: number;
  totalVisits: number;
  riskDistribution: {
    low: number;
    moderate: number;
    high: number;
    emergency: number;
  };
  referralRate: number;
  avgHb: number;
  avgBPSystolic: number;
  avgBPDiastolic: number;
  monthlyTrends: Array<{
    month: string;
    visits: number;
    low: number;
    moderate: number;
    high: number;
    emergency: number;
  }>;
  facilityStats: Array<{
    id: string;
    name: string;
    totalPatients: number;
    totalVisits: number;
    riskDistribution: {
      low: number;
      moderate: number;
      high: number;
      emergency: number;
    };
    referralRate: number;
    avgHb: number;
  }>;
  referralCompletionRate: number;
}

interface DashboardViewProps {
  stats: DashboardStats;
  patients: Patient[];
  visits: Visit[];
  onSelectPatient: (id: string) => void;
  role: string;
}

export default function DashboardView({ stats, patients, visits, onSelectPatient, role }: DashboardViewProps) {
  const [searchTerm, setSearchTerm] = React.useState('');
  const [riskFilter, setRiskFilter] = React.useState<string>('all');
  const [facilityFilter, setFacilityFilter] = React.useState<string>('all');

  const filteredPatients = patients.filter(p => {
    const matchesSearch = 
      p.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.phone.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.lga.toLowerCase().includes(searchTerm.toLowerCase());
      
    // Find latest visit for this patient to filter by risk category
    const pVisits = visits.filter(v => v.patientId === p.id);
    const latestVisit = pVisits.length > 0 
      ? pVisits.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())[0]
      : null;
    const currentRisk = latestVisit ? latestVisit.riskCategory : 'low';
    const matchesRisk = riskFilter === 'all' || currentRisk === riskFilter;
    
    const matchesFacility = facilityFilter === 'all' || p.facility === facilityFilter;

    return matchesSearch && matchesRisk && matchesFacility;
  });

  const uniqueFacilities = Array.from(new Set(patients.map(p => p.facility)));

  // Generate CSV for Patient Roster Export
  const exportToCSV = () => {
    const headers = ['Patient ID', 'Name', 'Age', 'Phone', 'LGA', 'State', 'Facility', 'Gravidity', 'Parity', 'EDD', 'Gestational Age (weeks)', 'Prev CS', 'Prev Stillbirth', 'Prev PPH', 'Risk Category'];
    const rows = filteredPatients.map(p => {
      const pVisits = visits.filter(v => v.patientId === p.id);
      const latest = pVisits.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())[0];
      const risk = latest ? latest.riskCategory.toUpperCase() : 'LOW';
      return [
        p.id,
        p.name,
        p.age,
        p.phone,
        p.lga,
        p.state,
        p.facility,
        p.gravidity,
        p.parity,
        p.edd,
        p.gestationalAge,
        p.previousCS ? 'YES' : 'NO',
        p.previousStillbirth ? 'YES' : 'NO',
        p.previousPPH ? 'YES' : 'NO',
        risk
      ];
    });

    const csvContent = "data:text/csv;charset=utf-8," 
      + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `maternite_patient_roster_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6" id="dashboard-view-root">
      
      {/* 1. Alerts & Critical Banners for high-risk and emergencies */}
      {visits.some(v => v.riskCategory === 'emergency' || (v.riskCategory === 'high' && v.systolic >= 150)) && (
        <div className="bg-red-50 border-l-4 border-red-600 p-4 rounded-r-lg shadow-sm animate-pulse flex items-start gap-3" id="emergency-alert-banner">
          <ShieldAlert className="text-red-600 shrink-0 mt-0.5" size={20} />
          <div>
            <h4 className="text-sm font-semibold text-red-900">Active High-Risk & Maternal Emergencies Flagged</h4>
            <p className="text-xs text-red-700 mt-1">
              Deterministic rule checks have highlighted patients requiring immediate primary-to-secondary facility referral. Ensure Magnesium Sulfate is ready for transport stabilization.
            </p>
          </div>
        </div>
      )}

      {/* 2. Top-level stats (Bento Grid layout) */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5" id="stats-bento-grid">
        
        {/* Total Patients */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200/60 shadow-[0_2px_12px_rgba(0,0,0,0.03)] hover:shadow-[0_4px_20px_rgba(0,0,0,0.06)] hover:scale-[1.02] transition-all duration-300 flex items-center gap-4 group">
          <div className="p-3 bg-teal-50 text-teal-600 rounded-xl group-hover:scale-110 transition-transform duration-300">
            <Users size={22} className="stroke-[2.5]" />
          </div>
          <div>
            <span className="text-[11px] text-slate-400 font-bold uppercase tracking-wider block font-display">Total ANC Patients</span>
            <span className="text-3xl font-black text-slate-800 font-mono tracking-tight">{stats.totalPatients}</span>
          </div>
        </div>

        {/* Total Visits */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200/60 shadow-[0_2px_12px_rgba(0,0,0,0.03)] hover:shadow-[0_4px_20px_rgba(0,0,0,0.06)] hover:scale-[1.02] transition-all duration-300 flex items-center gap-4 group">
          <div className="p-3 bg-indigo-50 text-indigo-600 rounded-xl group-hover:scale-110 transition-transform duration-300">
            <Activity size={22} className="stroke-[2.5]" />
          </div>
          <div>
            <span className="text-[11px] text-slate-400 font-bold uppercase tracking-wider block font-display">Total Visits Logged</span>
            <span className="text-3xl font-black text-slate-800 font-mono tracking-tight">{stats.totalVisits}</span>
          </div>
        </div>

        {/* Avg Haemoglobin */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200/60 shadow-[0_2px_12px_rgba(0,0,0,0.03)] hover:shadow-[0_4px_20px_rgba(0,0,0,0.06)] hover:scale-[1.02] transition-all duration-300 flex items-center gap-4 group">
          <div className={`p-3 rounded-xl group-hover:scale-110 transition-transform duration-300 ${stats.avgHb < 11 ? 'bg-amber-50 text-amber-600' : 'bg-emerald-50 text-emerald-600'}`}>
            <Droplet size={22} className="stroke-[2.5]" />
          </div>
          <div>
            <span className="text-[11px] text-slate-400 font-bold uppercase tracking-wider block font-display">Avg Haemoglobin</span>
            <div className="flex items-baseline gap-1">
              <span className="text-3xl font-black text-slate-800 font-mono tracking-tight">{stats.avgHb}</span>
              <span className="text-xs text-slate-400 font-bold font-mono">g/dL</span>
            </div>
          </div>
        </div>

        {/* Referral Rate */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200/60 shadow-[0_2px_12px_rgba(0,0,0,0.03)] hover:shadow-[0_4px_20px_rgba(0,0,0,0.06)] hover:scale-[1.02] transition-all duration-300 flex items-center gap-4 group">
          <div className="p-3 bg-red-50 text-red-600 rounded-xl group-hover:scale-110 transition-transform duration-300">
            <ArrowRightLeft size={22} className="stroke-[2.5]" />
          </div>
          <div>
            <span className="text-[11px] text-slate-400 font-bold uppercase tracking-wider block font-display">Referral Rate</span>
            <div className="flex items-baseline gap-1">
              <span className="text-3xl font-black text-slate-800 font-mono tracking-tight">{stats.referralRate}%</span>
            </div>
          </div>
        </div>

      </div>

      {/* 3. Graphical Trends and Risks overview */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6" id="dashboard-charts-grid">
        
        {/* Risk Distribution Card */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200/60 shadow-[0_2px_12px_rgba(0,0,0,0.03)] hover:shadow-[0_4px_16px_rgba(0,0,0,0.05)] transition-all duration-300 lg:col-span-1 flex flex-col justify-between">
          <div>
            <h3 className="text-sm font-bold text-slate-800 mb-5 flex items-center gap-2 font-display">
              <Heart className="text-teal-600 stroke-[2.5]" size={16} /> Risk Stratification Profile
            </h3>
            <div className="space-y-4">
              {/* Emergency */}
              <div>
                <div className="flex justify-between text-xs mb-1.5">
                  <span className="font-bold text-red-600 uppercase tracking-wide text-[10px] font-display">Emergency / Crises</span>
                  <span className="text-slate-500 font-bold font-mono">{stats.riskDistribution.emergency} <span className="text-[10px] text-slate-400">({stats.totalVisits ? Math.round((stats.riskDistribution.emergency / stats.totalVisits) * 100) : 0}%)</span></span>
                </div>
                <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                  <div className="bg-red-600 h-full rounded-full transition-all duration-500" style={{ width: `${stats.totalVisits ? (stats.riskDistribution.emergency / stats.totalVisits) * 100 : 0}%` }} />
                </div>
              </div>

              {/* High Risk */}
              <div>
                <div className="flex justify-between text-xs mb-1.5">
                  <span className="font-bold text-orange-500 uppercase tracking-wide text-[10px] font-display">High Risk</span>
                  <span className="text-slate-500 font-bold font-mono">{stats.riskDistribution.high} <span className="text-[10px] text-slate-400">({stats.totalVisits ? Math.round((stats.riskDistribution.high / stats.totalVisits) * 100) : 0}%)</span></span>
                </div>
                <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                  <div className="bg-orange-500 h-full rounded-full transition-all duration-500" style={{ width: `${stats.totalVisits ? (stats.riskDistribution.high / stats.totalVisits) * 100 : 0}%` }} />
                </div>
              </div>

              {/* Moderate Risk */}
              <div>
                <div className="flex justify-between text-xs mb-1.5">
                  <span className="font-bold text-amber-500 uppercase tracking-wide text-[10px] font-display">Moderate Risk</span>
                  <span className="text-slate-500 font-bold font-mono">{stats.riskDistribution.moderate} <span className="text-[10px] text-slate-400">({stats.totalVisits ? Math.round((stats.riskDistribution.moderate / stats.totalVisits) * 100) : 0}%)</span></span>
                </div>
                <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                  <div className="bg-amber-500 h-full rounded-full transition-all duration-500" style={{ width: `${stats.totalVisits ? (stats.riskDistribution.moderate / stats.totalVisits) * 100 : 0}%` }} />
                </div>
              </div>

              {/* Low Risk */}
              <div>
                <div className="flex justify-between text-xs mb-1.5">
                  <span className="font-bold text-emerald-500 uppercase tracking-wide text-[10px] font-display">Low Risk</span>
                  <span className="text-slate-500 font-bold font-mono">{stats.riskDistribution.low} <span className="text-[10px] text-slate-400">({stats.totalVisits ? Math.round((stats.riskDistribution.low / stats.totalVisits) * 100) : 0}%)</span></span>
                </div>
                <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                  <div className="bg-emerald-500 h-full rounded-full transition-all duration-500" style={{ width: `${stats.totalVisits ? (stats.riskDistribution.low / stats.totalVisits) * 100 : 0}%` }} />
                </div>
              </div>
            </div>
          </div>

          <div className="pt-4 mt-5 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500 bg-slate-50/50 p-3.5 rounded-xl border border-slate-100">
            <div className="flex items-center gap-1.5">
              <CheckCircle size={14} className="text-emerald-500" />
              <span className="font-medium text-slate-600 font-display">Referral Completion Rate:</span>
            </div>
            <span className="font-bold text-slate-800 font-mono">{stats.referralCompletionRate}%</span>
          </div>
        </div>

        {/* Antenatal Booking Trends Graph */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200/60 shadow-[0_2px_12px_rgba(0,0,0,0.03)] hover:shadow-[0_4px_16px_rgba(0,0,0,0.05)] transition-all duration-300 lg:col-span-2">
          <h3 className="text-sm font-bold text-slate-800 mb-5 flex items-center gap-2 font-display">
            <TrendingUp className="text-indigo-600 stroke-[2.5]" size={16} /> Monthly Antenatal Visits Trend
          </h3>
          <div className="h-[230px]" id="trends-chart-container">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={stats.monthlyTrends} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorVisits" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#6366f1" stopOpacity={0.2}/>
                    <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="month" stroke="#94a3b8" fontSize={11} tickLine={false} />
                <YAxis stroke="#94a3b8" fontSize={11} tickLine={false} />
                <Tooltip contentStyle={{ fontSize: '11px', borderRadius: '12px', border: '1px solid #e2e8f0', boxShadow: '0 4px 12px rgba(0,0,0,0.05)' }} />
                <Area type="monotone" dataKey="visits" name="Visits" stroke="#6366f1" strokeWidth={2.5} fillOpacity={1} fill="url(#colorVisits)" />
                <Legend wrapperStyle={{ fontSize: '11px', marginTop: '10px' }} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

      </div>

      {/* 4. Facility comparison table for District Officers/Programme Managers */}
      {(role === 'district_officer' || role === 'state_manager' || role === 'admin') && (
        <div className="bg-white rounded-2xl border border-slate-200/60 shadow-[0_2px_12px_rgba(0,0,0,0.03)] hover:shadow-[0_4px_16px_rgba(0,0,0,0.05)] transition-all duration-300 overflow-hidden" id="facility-comparison-card">
          <div className="p-5 border-b border-slate-100 flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2 font-display">
              <Building2 className="text-teal-600 stroke-[2.5]" size={16} /> Secondary & Primary Facility Analytics Comparison
            </h3>
            <span className="text-[10px] text-slate-400 font-bold font-mono bg-slate-50 px-2 py-1 rounded border border-slate-100">FCT Pilot District Command</span>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-50/70 text-slate-400 font-bold uppercase tracking-wider text-[10px] border-b border-slate-150">
                  <th className="p-4 pl-6 font-display">Facility Name</th>
                  <th className="p-4 font-display">Total Patients</th>
                  <th className="p-4 font-display">Total Visits</th>
                  <th className="p-4 text-center font-display">Emergency / High Risk</th>
                  <th className="p-4 text-center font-display">Avg Haemoglobin</th>
                  <th className="p-4 text-center font-display">Referral Rate</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-600 font-medium">
                {stats.facilityStats.map(fac => {
                  const highRiskCount = fac.riskDistribution.high + fac.riskDistribution.emergency;
                  return (
                    <tr key={fac.id} className="hover:bg-slate-50/40 transition-colors">
                      <td className="p-4 pl-6 font-semibold text-slate-800">{fac.name}</td>
                      <td className="p-4 font-mono font-semibold">{fac.totalPatients}</td>
                      <td className="p-4 font-mono font-semibold">{fac.totalVisits}</td>
                      <td className="p-4 text-center">
                        <span className={`inline-block px-2.5 py-1 rounded-full font-bold font-mono text-[10px] ${highRiskCount > 0 ? 'bg-red-50 text-red-600 border border-red-100' : 'bg-slate-100 text-slate-500 border border-slate-200/50'}`}>
                          {highRiskCount}
                        </span>
                      </td>
                      <td className={`p-4 text-center font-mono font-semibold ${fac.avgHb < 11 ? 'text-amber-600 font-bold' : 'text-slate-700'}`}>{fac.avgHb} g/dL</td>
                      <td className="p-4 text-center font-mono font-bold text-indigo-600">{fac.referralRate}%</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 5. Patient Ledger Roster */}
      <div className="bg-white rounded-2xl border border-slate-200/60 shadow-[0_2px_12px_rgba(0,0,0,0.03)] hover:shadow-[0_4px_16px_rgba(0,0,0,0.05)] transition-all duration-300 overflow-hidden" id="patient-roster-card">
        <div className="p-5 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2 font-display">
              <FileText className="text-teal-600 stroke-[2.5]" size={16} /> Clinical Patient Roster
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">Early stratification ledger for primary facilities</p>
          </div>
          <div className="flex items-center gap-2 self-start sm:self-auto">
            <button 
              onClick={exportToCSV}
              className="text-xs font-bold px-3.5 py-2 bg-slate-50 hover:bg-slate-100 text-slate-600 rounded-xl flex items-center gap-1.5 border border-slate-200 transition-all duration-200 hover:scale-[1.02] active:scale-95 cursor-pointer"
            >
              <FileDown size={14} /> Export CSV Ledger
            </button>
          </div>
        </div>

        {/* Filters */}
        <div className="p-4 bg-slate-50/70 border-b border-slate-100 grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="relative">
            <Search className="absolute left-3.5 top-3 text-slate-400" size={13} />
            <input 
              type="text" 
              placeholder="Search Name, ID, Phone..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full text-xs pl-9 pr-3 py-2.5 bg-white rounded-xl border border-slate-200 focus:outline-none focus:ring-1 focus:ring-teal-500 placeholder-slate-400 font-medium transition-all duration-200 focus:border-teal-500"
            />
          </div>

          <div>
            <select
              value={riskFilter}
              onChange={(e) => setRiskFilter(e.target.value)}
              className="w-full text-xs px-3 py-2.5 bg-white rounded-xl border border-slate-200 focus:outline-none focus:ring-1 focus:ring-teal-500 font-semibold text-slate-700 cursor-pointer transition-all duration-200 focus:border-teal-500"
            >
              <option value="all">All Risk Classes</option>
              <option value="low">Low Risk Category</option>
              <option value="moderate">Moderate Risk Category</option>
              <option value="high">High Risk Category</option>
              <option value="emergency">Emergency / Critical Category</option>
            </select>
          </div>

          <div>
            <select
              value={facilityFilter}
              onChange={(e) => setFacilityFilter(e.target.value)}
              className="w-full text-xs px-3 py-2.5 bg-white rounded-xl border border-slate-200 focus:outline-none focus:ring-1 focus:ring-teal-500 font-semibold text-slate-700 cursor-pointer transition-all duration-200 focus:border-teal-500"
            >
              <option value="all">All Registered Facilities</option>
              {uniqueFacilities.map(fac => (
                <option key={fac} value={fac}>{fac}</option>
              ))}
            </select>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-50/40 text-slate-400 font-bold uppercase tracking-wider text-[10px] border-b border-slate-150">
                <th className="p-4 pl-6 font-display">Patient ID</th>
                <th className="p-4 font-display">Name</th>
                <th className="p-4 font-display">LGA & Facility</th>
                <th className="p-4 font-display">Gest. Age / EDD</th>
                <th className="p-4 text-center font-display">Parity / Gravidity</th>
                <th className="p-4 text-center font-display">Status Category</th>
                <th className="p-4 pr-6 text-right font-display">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-600 font-medium">
              {filteredPatients.length === 0 ? (
                <tr>
                  <td colSpan={7} className="p-12 text-center text-slate-400 font-semibold font-display italic">
                    No matching patient records found in this facility ledger.
                  </td>
                </tr>
              ) : (
                filteredPatients.map(p => {
                  const pVisits = visits.filter(v => v.patientId === p.id);
                  const latest = pVisits.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())[0];
                  const currentRisk = latest ? latest.riskCategory : 'low';
                  
                  return (
                    <tr key={p.id} className="hover:bg-slate-50/30 transition-colors">
                      <td className="p-4 pl-6 font-mono font-bold text-slate-900 text-[11px]">{p.id}</td>
                      <td className="p-4">
                        <div className="font-bold text-slate-800 font-display text-sm">{p.name}</div>
                        <div className="text-slate-400 font-semibold text-[10px] mt-0.5">{p.age} yrs • {p.phone || 'No contact phone'}</div>
                      </td>
                      <td className="p-4">
                        <div className="font-semibold text-slate-700">{p.facility}</div>
                        <div className="text-slate-400 font-bold text-[10px] mt-0.5 uppercase tracking-wide">{p.lga}, {p.state}</div>
                      </td>
                      <td className="p-4">
                        <div className="font-bold text-slate-700 font-mono">{p.gestationalAge} Weeks</div>
                        <div className="text-slate-400 font-semibold text-[10px] mt-0.5">EDD: {p.edd}</div>
                      </td>
                      <td className="p-4 text-center font-mono font-bold text-slate-700 text-[11px]">
                        G{p.gravidity} P{p.parity}
                      </td>
                      <td className="p-4 text-center">
                        <span className={`inline-block px-3 py-1 rounded-full font-bold uppercase text-[9px] text-center tracking-wider border shadow-sm
                          ${currentRisk === 'emergency' ? 'bg-red-50 text-red-700 border-red-200' : ''}
                          ${currentRisk === 'high' ? 'bg-orange-50 text-orange-700 border-orange-200' : ''}
                          ${currentRisk === 'moderate' ? 'bg-amber-50 text-amber-700 border-amber-200' : ''}
                          ${currentRisk === 'low' ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : ''}
                        `}>
                          {currentRisk}
                        </span>
                      </td>
                      <td className="p-4 pr-6 text-right">
                        <button 
                          onClick={() => onSelectPatient(p.id)}
                          className="px-4 py-1.5 text-xs font-bold bg-teal-50 hover:bg-teal-100 text-teal-700 rounded-xl transition-all duration-200 hover:scale-[1.03] active:scale-95 cursor-pointer border border-teal-100"
                        >
                          View Dossier
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
}

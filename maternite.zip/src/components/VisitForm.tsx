/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { ArrowLeft, Heart, Droplet, ClipboardList, Activity, BrainCircuit, Sparkles, CheckCircle2 } from 'lucide-react';
import { Patient, Visit, RiskLevel } from '../types';
import { evaluateRisk } from '../lib/riskEngine';

interface VisitFormProps {
  patient: Patient;
  onBack: () => void;
  onSubmit: (visitData: any) => void;
  role: string;
}

export default function VisitForm({ patient, onBack, onSubmit, role }: VisitFormProps) {
  const [activeTab, setActiveTab] = React.useState<'vitals_labs' | 'obstetric' | 'symptoms_history'>('vitals_labs');
  
  const [formData, setFormData] = React.useState({
    systolic: '120',
    diastolic: '80',
    weight: '62',
    height: '160',
    bmi: '24.2',
    temperature: '36.6',
    pulse: '80',
    respRate: '18',
    hb: '11',
    urineProtein: 'negative' as const,
    urineGlucose: 'negative' as const,
    bloodGroup: 'O' as const,
    rhesus: '+' as const,
    gestationalAge: String(patient.gestationalAge || 12),
    fundalHeight: '20',
    fetalHeartRate: '140',
    fetalMovement: 'normal' as const,
    presentation: 'cephalic' as const,
    symptoms: {
      headache: false,
      blurredVision: false,
      swelling: false,
      bleeding: false,
      convulsions: false,
      fever: false,
      reducedFetalMovement: false,
      abdominalPain: false,
      vomiting: false
    },
    history: {
      hypertension: false,
      diabetes: false,
      hiv: false,
      malaria: false,
      sickleCell: false,
      tuberculosis: false,
      multiplePregnancy: false,
      smoking: false,
      alcohol: false,
      drugUse: false,
      previousPreeclampsia: false
    },
    referralFacility: 'General Hospital Garki'
  });

  const [errors, setErrors] = React.useState<Record<string, string>>({});

  // Recalculate BMI automatically when weight or height change
  React.useEffect(() => {
    const w = Number(formData.weight);
    const h = Number(formData.height) / 100; // cm to m
    if (w > 0 && h > 0) {
      const calculatedBmi = (w / (h * h)).toFixed(1);
      setFormData(prev => ({ ...prev, bmi: calculatedBmi }));
    }
  }, [formData.weight, formData.height]);

  // Recalculate deterministic risk on the fly to show reactive assessment panel
  const currentLiveAssessment = React.useMemo(() => {
    // Pack Partial<Visit>
    const mockVisit: Partial<Visit> = {
      gestationalAge: Number(formData.gestationalAge),
      systolic: Number(formData.systolic || 120),
      diastolic: Number(formData.diastolic || 80),
      weight: Number(formData.weight || 60),
      height: Number(formData.height || 160),
      bmi: Number(formData.bmi || 23.4),
      temperature: Number(formData.temperature || 36.6),
      pulse: Number(formData.pulse || 80),
      respRate: Number(formData.respRate || 18),
      hb: Number(formData.hb || 11),
      urineProtein: formData.urineProtein,
      urineGlucose: formData.urineGlucose,
      fetalHeartRate: Number(formData.fetalHeartRate || 0),
      fetalMovement: formData.fetalMovement,
      presentation: formData.presentation,
      symptoms: formData.symptoms,
      history: formData.history
    };

    return evaluateRisk(patient, mockVisit);
  }, [formData, patient]);

  const validate = () => {
    const newErrors: Record<string, string> = {};
    
    // BP check
    const sys = Number(formData.systolic);
    const dia = Number(formData.diastolic);
    if (!formData.systolic || sys < 50 || sys > 250) newErrors.systolic = 'Enter valid Systolic BP (50 - 250).';
    if (!formData.diastolic || dia < 30 || dia > 150) newErrors.diastolic = 'Enter valid Diastolic BP (30 - 150).';
    
    // Weight & Height
    if (!formData.weight || Number(formData.weight) < 30 || Number(formData.weight) > 200) newErrors.weight = 'Enter valid Weight.';
    if (!formData.height || Number(formData.height) < 100 || Number(formData.height) > 220) newErrors.height = 'Enter valid Height.';

    // Lab Hb
    const hb = Number(formData.hb);
    if (!formData.hb || hb < 3 || hb > 18) newErrors.hb = 'Enter valid Haemoglobin level (3 - 18).';

    // Gestational Age
    const ga = Number(formData.gestationalAge);
    if (!formData.gestationalAge || ga < 1 || ga > 44) newErrors.gestationalAge = 'Enter gestational weeks (1-44).';

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleCheckboxChange = (section: 'symptoms' | 'history', key: string) => {
    setFormData(prev => ({
      ...prev,
      [section]: {
        ...prev[section],
        [key]: !prev[section][key as keyof typeof prev[typeof section]]
      }
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validate()) {
      onSubmit({
        ...formData,
        systolic: Number(formData.systolic),
        diastolic: Number(formData.diastolic),
        weight: Number(formData.weight),
        height: Number(formData.height),
        bmi: Number(formData.bmi),
        temperature: Number(formData.temperature),
        pulse: Number(formData.pulse),
        respRate: Number(formData.respRate),
        hb: Number(formData.hb),
        fundalHeight: Number(formData.fundalHeight || 0),
        fetalHeartRate: Number(formData.fetalHeartRate || 0),
        gestationalAge: Number(formData.gestationalAge),
        clinicianRole: role,
        clinicianName: role === 'midwife' ? 'Sister Grace Nwosu' : role === 'chew' ? 'CHEW Joshua Adamu' : 'Facility Administrator'
      });
    } else {
      // Find where the errors are and guide the tab switch
      if (newErrorsFoundInVitals()) {
        setActiveTab('vitals_labs');
      } else if (newErrorsFoundInObstetric()) {
        setActiveTab('obstetric');
      }
    }
  };

  const newErrorsFoundInVitals = () => {
    return errors.systolic || errors.diastolic || errors.weight || errors.height || errors.hb;
  };

  const newErrorsFoundInObstetric = () => {
    return errors.gestationalAge;
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6" id="visit-form-root">
      
      {/* Left Columns (Intake inputs panel) */}
      <div className="lg:col-span-2 space-y-4">
        <div className="bg-white rounded-2xl border border-slate-200/60 shadow-[0_2px_12px_rgba(0,0,0,0.03)] p-6 space-y-6">
          
          {/* Form Header */}
          <div className="flex items-center justify-between pb-4 border-b border-slate-100">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-teal-50 text-teal-600 rounded-xl">
                <ClipboardList size={20} className="stroke-[2.5]" />
              </div>
              <div>
                <h2 className="text-base font-black text-slate-800 font-display tracking-tight leading-none">ANC Visit Form • {patient.name}</h2>
                <p className="text-xs text-slate-400 mt-1 font-semibold">Record diagnostic markers for maternal risk profiling</p>
              </div>
            </div>
            <button 
              onClick={onBack}
              className="text-xs font-bold text-slate-500 hover:text-slate-800 flex items-center gap-1.5 transition-all duration-200 hover:scale-[1.02] active:scale-95 cursor-pointer"
            >
              <ArrowLeft size={14} /> Back
            </button>
          </div>

          {/* Staged Form Tabs Selector */}
          <div className="flex border-b border-slate-150 text-xs font-bold">
            <button
              onClick={() => setActiveTab('vitals_labs')}
              className={`pb-3 px-4 border-b-2 transition-all duration-200 font-display cursor-pointer ${activeTab === 'vitals_labs' ? 'border-teal-600 text-teal-700' : 'border-transparent text-slate-400 hover:text-slate-600'}`}
            >
              1. Physical Vitals & Lab Output
            </button>
            <button
              onClick={() => setActiveTab('obstetric')}
              className={`pb-3 px-4 border-b-2 transition-all duration-200 font-display cursor-pointer ${activeTab === 'obstetric' ? 'border-teal-600 text-teal-700' : 'border-transparent text-slate-400 hover:text-slate-600'}`}
            >
              2. Obstetric Examination
            </button>
            <button
              onClick={() => setActiveTab('symptoms_history')}
              className={`pb-3 px-4 border-b-2 transition-all duration-200 font-display cursor-pointer ${activeTab === 'symptoms_history' ? 'border-teal-600 text-teal-700' : 'border-transparent text-slate-400 hover:text-slate-600'}`}
            >
              3. Symptoms & Co-morbidities
            </button>
          </div>

          {/* Form Content body */}
          <form onSubmit={handleSubmit} className="space-y-6 text-xs font-medium">
            
            {/* Tab 1: Vitals & Labs */}
            {activeTab === 'vitals_labs' && (
              <div className="space-y-6 animate-fadeIn" id="tab-vitals-labs">
                
                {/* Section: Physical Vitals */}
                <div className="space-y-3">
                  <span className="text-[10px] font-black text-slate-400 uppercase tracking-wider block font-display">Physical Vitals</span>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    
                    {/* Systolic BP */}
                    <div className="space-y-1.5">
                      <label className="font-bold text-slate-700 font-display">Systolic Blood Pressure (mmHg) <span className="text-red-500">*</span></label>
                      <input 
                        type="number"
                        placeholder="E.g., 120"
                        value={formData.systolic}
                        onChange={(e) => setFormData(prev => ({ ...prev, systolic: e.target.value }))}
                        className={`w-full px-3 py-2.5 bg-slate-50/50 border rounded-xl focus:outline-none focus:ring-1 focus:ring-teal-500 focus:bg-white focus:border-teal-500 transition-all duration-200 font-semibold font-mono ${errors.systolic ? 'border-red-300 bg-red-50/10' : 'border-slate-200'}`}
                      />
                      {errors.systolic && <p className="text-[10px] text-red-500 font-bold">{errors.systolic}</p>}
                    </div>

                    {/* Diastolic BP */}
                    <div className="space-y-1.5">
                      <label className="font-bold text-slate-700 font-display">Diastolic Blood Pressure (mmHg) <span className="text-red-500">*</span></label>
                      <input 
                        type="number"
                        placeholder="E.g., 80"
                        value={formData.diastolic}
                        onChange={(e) => setFormData(prev => ({ ...prev, diastolic: e.target.value }))}
                        className={`w-full px-3 py-2.5 bg-slate-50/50 border rounded-xl focus:outline-none focus:ring-1 focus:ring-teal-500 focus:bg-white focus:border-teal-500 transition-all duration-200 font-semibold font-mono ${errors.diastolic ? 'border-red-300 bg-red-50/10' : 'border-slate-200'}`}
                      />
                      {errors.diastolic && <p className="text-[10px] text-red-500 font-bold">{errors.diastolic}</p>}
                    </div>

                    {/* Temp */}
                    <div className="space-y-1.5">
                      <label className="font-bold text-slate-700 font-display">Temperature (°C)</label>
                      <input 
                        type="number" 
                        step="0.1"
                        placeholder="E.g., 36.6"
                        value={formData.temperature}
                        onChange={(e) => setFormData(prev => ({ ...prev, temperature: e.target.value }))}
                        className="w-full px-3 py-2.5 bg-slate-50/50 border border-slate-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-teal-500 focus:bg-white focus:border-teal-500 transition-all duration-200 font-semibold font-mono"
                      />
                    </div>

                    {/* Weight */}
                    <div className="space-y-1.5">
                      <label className="font-bold text-slate-700 font-display">Maternal Weight (kg) <span className="text-red-500">*</span></label>
                      <input 
                        type="number"
                        placeholder="E.g., 65"
                        value={formData.weight}
                        onChange={(e) => setFormData(prev => ({ ...prev, weight: e.target.value }))}
                        className={`w-full px-3 py-2.5 bg-slate-50/50 border rounded-xl focus:outline-none focus:ring-1 focus:ring-teal-500 focus:bg-white focus:border-teal-500 transition-all duration-200 font-semibold font-mono ${errors.weight ? 'border-red-300 bg-red-50/10' : 'border-slate-200'}`}
                      />
                      {errors.weight && <p className="text-[10px] text-red-500 font-bold">{errors.weight}</p>}
                    </div>

                    {/* Height */}
                    <div className="space-y-1.5">
                      <label className="font-bold text-slate-700 font-display">Maternal Height (cm) <span className="text-red-500">*</span></label>
                      <input 
                        type="number"
                        placeholder="E.g., 162"
                        value={formData.height}
                        onChange={(e) => setFormData(prev => ({ ...prev, height: e.target.value }))}
                        className={`w-full px-3 py-2.5 bg-slate-50/50 border rounded-xl focus:outline-none focus:ring-1 focus:ring-teal-500 focus:bg-white focus:border-teal-500 transition-all duration-200 font-semibold font-mono ${errors.height ? 'border-red-300 bg-red-50/10' : 'border-slate-200'}`}
                      />
                      {errors.height && <p className="text-[10px] text-red-500 font-bold">{errors.height}</p>}
                    </div>

                    {/* BMI (Calculated) */}
                    <div className="space-y-1.5">
                      <label className="font-bold text-slate-400 font-display">Calculated Body Mass Index (BMI)</label>
                      <input 
                        type="text" 
                        disabled 
                        value={formData.bmi}
                        className="w-full px-3 py-2.5 bg-slate-100 border border-slate-200 text-slate-500 rounded-xl font-mono font-bold"
                      />
                    </div>

                    {/* Pulse Rate */}
                    <div className="space-y-1.5">
                      <label className="font-bold text-slate-700 font-display">Pulse Rate (bpm)</label>
                      <input 
                        type="number"
                        placeholder="E.g., 80"
                        value={formData.pulse}
                        onChange={(e) => setFormData(prev => ({ ...prev, pulse: e.target.value }))}
                        className="w-full px-3 py-2.5 bg-slate-50/50 border border-slate-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-teal-500 focus:bg-white focus:border-teal-500 transition-all duration-200 font-semibold font-mono"
                      />
                    </div>

                    {/* Respiratory Rate */}
                    <div className="space-y-1.5">
                      <label className="font-bold text-slate-700 font-display">Respiratory Rate (bpm)</label>
                      <input 
                        type="number"
                        placeholder="E.g., 18"
                        value={formData.respRate}
                        onChange={(e) => setFormData(prev => ({ ...prev, respRate: e.target.value }))}
                        className="w-full px-3 py-2.5 bg-slate-50/50 border border-slate-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-teal-500 focus:bg-white focus:border-teal-500 transition-all duration-200 font-semibold font-mono"
                      />
                    </div>

                  </div>
                </div>

                {/* Section: Lab Investigations */}
                <div className="space-y-3 pt-4 border-t border-slate-150">
                  <span className="text-[10px] font-black text-slate-400 uppercase tracking-wider block font-display">Maternal Laboratory Reports</span>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                    
                    {/* Haemoglobin Hb */}
                    <div className="space-y-1.5">
                      <label className="font-bold text-slate-700 flex items-center gap-1 font-display"><Droplet size={12} className="text-red-500 stroke-[2.5]" /> Haemoglobin (g/dL) <span className="text-red-500">*</span></label>
                      <input 
                        type="number" 
                        step="0.1"
                        placeholder="E.g., 11.0"
                        value={formData.hb}
                        onChange={(e) => setFormData(prev => ({ ...prev, hb: e.target.value }))}
                        className={`w-full px-3 py-2.5 bg-slate-50/50 border rounded-xl focus:outline-none focus:ring-1 focus:ring-teal-500 focus:bg-white focus:border-teal-500 transition-all duration-200 font-semibold font-mono ${errors.hb ? 'border-red-300 bg-red-50/10' : 'border-slate-200'}`}
                      />
                      {errors.hb && <p className="text-[10px] text-red-500 font-bold">{errors.hb}</p>}
                    </div>

                    {/* Urine Protein */}
                    <div className="space-y-1.5">
                      <label className="font-bold text-slate-700 font-display">Urine Protein (Proteinuria)</label>
                      <select
                        value={formData.urineProtein}
                        onChange={(e: any) => setFormData(prev => ({ ...prev, urineProtein: e.target.value }))}
                        className="w-full px-3 py-2.5 bg-slate-50/50 border border-slate-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-teal-500 focus:bg-white focus:border-teal-500 transition-all duration-200 font-semibold cursor-pointer text-slate-700"
                      >
                        <option value="negative">Negative</option>
                        <option value="1+">Trace / 1+</option>
                        <option value="2+">2+</option>
                        <option value="3+">3+</option>
                        <option value="4+">4+</option>
                      </select>
                    </div>

                    {/* Urine Glucose */}
                    <div className="space-y-1.5">
                      <label className="font-bold text-slate-700 font-display">Urine Glucose (Glycosuria)</label>
                      <select
                        value={formData.urineGlucose}
                        onChange={(e: any) => setFormData(prev => ({ ...prev, urineGlucose: e.target.value }))}
                        className="w-full px-3 py-2.5 bg-slate-50/50 border border-slate-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-teal-500 focus:bg-white focus:border-teal-500 transition-all duration-200 font-semibold cursor-pointer text-slate-700"
                      >
                        <option value="negative">Negative</option>
                        <option value="1+">1+</option>
                        <option value="2+">2+</option>
                        <option value="3+">3+</option>
                        <option value="4+">4+</option>
                      </select>
                    </div>

                    {/* Blood Group / Rhesus */}
                    <div className="space-y-1.5">
                      <label className="font-bold text-slate-700 font-display">Blood Group / Rhesus</label>
                      <div className="flex gap-1.5">
                        <select
                          value={formData.bloodGroup}
                          onChange={(e: any) => setFormData(prev => ({ ...prev, bloodGroup: e.target.value }))}
                          className="w-full px-2 py-2.5 bg-slate-50/50 border border-slate-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-teal-500 focus:bg-white focus:border-teal-500 transition-all duration-200 font-bold cursor-pointer text-slate-700"
                        >
                          <option value="A">A</option>
                          <option value="B">B</option>
                          <option value="AB">AB</option>
                          <option value="O">O</option>
                        </select>
                        <select
                          value={formData.rhesus}
                          onChange={(e: any) => setFormData(prev => ({ ...prev, rhesus: e.target.value }))}
                          className="w-20 px-2 py-2.5 bg-slate-50/50 border border-slate-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-teal-500 focus:bg-white focus:border-teal-500 transition-all duration-200 font-bold cursor-pointer text-slate-700"
                        >
                          <option value="+">+</option>
                          <option value="-">-</option>
                        </select>
                      </div>
                    </div>

                  </div>
                </div>

                {/* Actions button */}
                <div className="flex justify-end pt-3">
                  <button
                    type="button"
                    onClick={() => setActiveTab('obstetric')}
                    className="px-4.5 py-2.5 bg-slate-950 hover:bg-slate-800 text-white font-bold rounded-xl transition-all duration-200 hover:scale-[1.02] active:scale-95 cursor-pointer shadow-sm"
                  >
                    Continue to Obstetric Exam
                  </button>
                </div>
              </div>
            )}

            {/* Tab 2: Obstetric Exam */}
            {activeTab === 'obstetric' && (
              <div className="space-y-6 animate-fadeIn" id="tab-obstetric">
                <div className="space-y-4">
                  <span className="text-[10px] font-black text-slate-400 uppercase tracking-wider block font-display">Clinical Obstetric Findings</span>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 font-semibold">
                    
                    {/* Gestational Age */}
                    <div className="space-y-1.5">
                      <label className="font-bold text-slate-700 font-display">Current Gestational Age (Weeks) <span className="text-red-500">*</span></label>
                      <input 
                        type="number"
                        min="1"
                        max="44"
                        value={formData.gestationalAge}
                        onChange={(e) => setFormData(prev => ({ ...prev, gestationalAge: e.target.value }))}
                        className={`w-full px-3 py-2.5 bg-slate-50/50 border rounded-xl focus:outline-none focus:ring-1 focus:ring-teal-500 focus:bg-white focus:border-teal-500 transition-all duration-200 font-mono font-bold ${errors.gestationalAge ? 'border-red-300 bg-red-50/10' : 'border-slate-200'}`}
                      />
                      {errors.gestationalAge && <p className="text-[10px] text-red-500 font-bold">{errors.gestationalAge}</p>}
                    </div>

                    {/* Fundal Height */}
                    <div className="space-y-1.5">
                      <label className="font-bold text-slate-700 font-display">Fundal Height (cm)</label>
                      <input 
                        type="number"
                        placeholder="E.g., 24"
                        value={formData.fundalHeight}
                        onChange={(e) => setFormData(prev => ({ ...prev, fundalHeight: e.target.value }))}
                        className="w-full px-3 py-2.5 bg-slate-50/50 border border-slate-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-teal-500 focus:bg-white focus:border-teal-500 transition-all duration-200 font-mono font-bold"
                      />
                    </div>

                    {/* Fetal Heart Rate */}
                    <div className="space-y-1.5">
                      <label className="font-bold text-slate-700 font-display">Fetal Heart Rate (bpm)</label>
                      <input 
                        type="number"
                        placeholder="E.g., 140"
                        value={formData.fetalHeartRate}
                        onChange={(e) => setFormData(prev => ({ ...prev, fetalHeartRate: e.target.value }))}
                        className="w-full px-3 py-2.5 bg-slate-50/50 border border-slate-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-teal-500 focus:bg-white focus:border-teal-500 transition-all duration-200 font-mono font-bold"
                      />
                    </div>

                    {/* Fetal Movement */}
                    <div className="space-y-1.5">
                      <label className="font-bold text-slate-700 font-display">Fetal Movement</label>
                      <select
                        value={formData.fetalMovement}
                        onChange={(e: any) => setFormData(prev => ({ ...prev, fetalMovement: e.target.value }))}
                        className="w-full px-3 py-2.5 bg-slate-50/50 border border-slate-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-teal-500 focus:bg-white focus:border-teal-500 transition-all duration-200 font-bold cursor-pointer text-slate-700"
                      >
                        <option value="normal">Normal / Active</option>
                        <option value="reduced">Reduced Fetal Movement</option>
                        <option value="absent">Absent Fetal Movement</option>
                      </select>
                    </div>

                    {/* Presentation */}
                    <div className="space-y-1.5">
                      <label className="font-bold text-slate-700 font-display">Fetal Presentation</label>
                      <select
                        value={formData.presentation}
                        onChange={(e: any) => setFormData(prev => ({ ...prev, presentation: e.target.value }))}
                        className="w-full px-3 py-2.5 bg-slate-50/50 border border-slate-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-teal-500 focus:bg-white focus:border-teal-500 transition-all duration-200 font-bold cursor-pointer text-slate-700"
                      >
                        <option value="cephalic">Cephalic (Head first)</option>
                        <option value="breech">Breech (Feet first)</option>
                        <option value="shoulder">Shoulder</option>
                        <option value="transverse">Transverse / Lie</option>
                        <option value="unknown">Unknown / Not assessable</option>
                      </select>
                    </div>

                  </div>
                </div>

                <div className="flex justify-between pt-3 border-t border-slate-100">
                  <button
                    type="button"
                    onClick={() => setActiveTab('vitals_labs')}
                    className="px-4 py-2.5 bg-white hover:bg-slate-50 text-slate-600 font-bold rounded-xl border border-slate-250 transition-all duration-200 hover:scale-[1.02] active:scale-95 cursor-pointer shadow-sm"
                  >
                    Back to Vitals
                  </button>
                  <button
                    type="button"
                    onClick={() => setActiveTab('symptoms_history')}
                    className="px-4.5 py-2.5 bg-slate-950 hover:bg-slate-800 text-white font-bold rounded-xl transition-all duration-200 hover:scale-[1.02] active:scale-95 cursor-pointer shadow-sm"
                  >
                    Continue to Symptoms Check
                  </button>
                </div>
              </div>
            )}

            {/* Tab 3: Symptoms & History */}
            {activeTab === 'symptoms_history' && (
              <div className="space-y-6 animate-fadeIn" id="tab-symptoms-history">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 font-semibold">
                  
                  {/* Warning Symptoms Checklist */}
                  <div className="bg-red-50/15 p-4 rounded-xl border border-red-100/60 space-y-3">
                    <span className="text-[10px] font-black text-red-800 uppercase tracking-wider block font-display">Warning Symptoms Checked Today</span>
                    <div className="space-y-2.5 pt-1 text-slate-700">
                      {Object.keys(formData.symptoms).map(key => (
                        <label key={key} className="flex items-center gap-3 cursor-pointer select-none">
                          <input 
                            type="checkbox"
                            checked={formData.symptoms[key as keyof typeof formData.symptoms]}
                            onChange={() => handleCheckboxChange('symptoms', key)}
                            className="w-4 h-4 rounded border-slate-300 text-red-600 focus:ring-red-500 cursor-pointer"
                          />
                          <span>{key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase()).trim()}</span>
                        </label>
                      ))}
                    </div>
                  </div>

                  {/* Co-morbidities & Chronic Histories */}
                  <div className="bg-amber-50/15 p-4 rounded-xl border border-amber-100/60 space-y-3">
                    <span className="text-[10px] font-black text-amber-800 uppercase tracking-wider block font-display">Co-morbidities & Obstetric Risks</span>
                    <div className="space-y-2.5 pt-1 text-slate-700">
                      {Object.keys(formData.history).map(key => (
                        <label key={key} className="flex items-center gap-3 cursor-pointer select-none">
                          <input 
                            type="checkbox"
                            checked={formData.history[key as keyof typeof formData.history]}
                            onChange={() => handleCheckboxChange('history', key)}
                            className="w-4 h-4 rounded border-slate-300 text-amber-600 focus:ring-amber-500 cursor-pointer"
                          />
                          <span>{key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase()).trim()}</span>
                        </label>
                      ))}
                    </div>
                  </div>

                </div>

                {/* Optional Referral Target Selection */}
                {currentLiveAssessment.referralNeeded && (
                  <div className="bg-amber-50/40 border border-amber-200/80 p-4 rounded-2xl space-y-2.5 animate-fadeIn">
                    <label className="font-bold text-amber-900 block font-display">Referral Target Facility</label>
                    <select
                      value={formData.referralFacility}
                      onChange={(e) => setFormData(prev => ({ ...prev, referralFacility: e.target.value }))}
                      className="w-full px-3 py-2.5 bg-white border border-amber-300/80 text-amber-950 rounded-xl focus:outline-none focus:ring-1 focus:ring-amber-500 font-bold"
                    >
                      <option value="General Hospital Garki">General Hospital Garki (FCT)</option>
                      <option value="Kubwa General Hospital">Kubwa General Hospital (FCT)</option>
                      <option value="National Hospital Abuja">National Hospital Abuja (Federal)</option>
                      <option value="Murtala Muhammad Specialist Hospital Kano">Murtala Muhammad Specialist Hospital Kano (Kano)</option>
                      <option value="Lagos University Teaching Hospital (LUTH)">Lagos University Teaching Hospital (LUTH)</option>
                    </select>
                    <span className="text-[10px] text-amber-700/90 font-semibold block leading-relaxed">A referral is required because the patient triggered high-risk or emergency deterministic rule protocols.</span>
                  </div>
                )}

                <div className="flex justify-between pt-3 border-t border-slate-150">
                  <button
                    type="button"
                    onClick={() => setActiveTab('obstetric')}
                    className="px-4 py-2.5 bg-white hover:bg-slate-50 text-slate-600 font-bold rounded-xl border border-slate-250 transition-all duration-200 hover:scale-[1.02] active:scale-95 cursor-pointer shadow-sm"
                  >
                    Back to Obstetric Exam
                  </button>
                  <button 
                    type="submit"
                    className="px-5 py-3 bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-700 hover:to-emerald-700 text-white rounded-xl font-bold flex items-center gap-2 shadow-sm hover:shadow-md transition-all duration-200 hover:scale-[1.02] active:scale-95 cursor-pointer"
                  >
                    <CheckCircle2 size={16} className="stroke-[2.5]" /> Save Visit & Stratify Patient
                  </button>
                </div>
              </div>
            )}

          </form>

        </div>
      </div>

      {/* Right Column: Reactive Clinical Decision Support Board */}
      <div className="lg:col-span-1 space-y-4" id="visit-form-risk-engine-panel">
        <div className="bg-white rounded-2xl border border-slate-200/60 shadow-[0_2px_12px_rgba(0,0,0,0.03)] p-5 space-y-5 sticky top-6">
          <div className="flex items-center gap-2 pb-3 border-b border-slate-150">
            <Heart className="text-teal-600 stroke-[2.5]" size={18} />
            <span className="text-xs font-bold text-slate-800 font-display">Live Decision Support Board</span>
          </div>

          {/* Color-coded Risk box */}
          <div className="space-y-2">
            <span className="text-[10px] font-black text-slate-400 uppercase tracking-wider block font-display">Deterministic Live Risk Class</span>
            <div className={`p-4 rounded-xl border text-center font-bold tracking-wider transition-all duration-300 font-display shadow-sm
              ${currentLiveAssessment.riskCategory === 'emergency' ? 'bg-red-50 border-red-200 text-red-700 text-base' : ''}
              ${currentLiveAssessment.riskCategory === 'high' ? 'bg-orange-50 border-orange-200 text-orange-700 text-sm' : ''}
              ${currentLiveAssessment.riskCategory === 'moderate' ? 'bg-amber-50 border-amber-200 text-amber-700 text-xs' : ''}
              ${currentLiveAssessment.riskCategory === 'low' ? 'bg-emerald-50 border-emerald-200 text-emerald-700 text-xs' : ''}
            `}>
              {currentLiveAssessment.riskCategory.toUpperCase()} RISK
            </div>
          </div>

          {/* ML prediction confidence estimation panel */}
          <div className="bg-slate-50/80 p-3.5 rounded-xl space-y-2 border border-slate-200">
            <span className="text-[10px] font-black text-slate-400 uppercase tracking-wider flex items-center gap-1.5 font-display">
              <BrainCircuit size={13} className="text-teal-600 stroke-[2.5]" /> Neural Network Estimator (Sim)
            </span>
            <div className="flex items-center justify-between text-[11px] text-slate-550 font-semibold">
              <span>Risk Probability Score:</span>
              <span className="font-bold font-mono text-slate-850 bg-white border border-slate-150 px-2 py-0.5 rounded shadow-sm">{Math.round(currentLiveAssessment.mlProbability * 100)}%</span>
            </div>
            <div className="flex items-center justify-between text-[11px] text-slate-550 font-semibold">
              <span>Classifier Confidence:</span>
              <span className="font-bold font-mono text-slate-850 bg-white border border-slate-150 px-2 py-0.5 rounded shadow-sm">{Math.round(currentLiveAssessment.mlConfidence * 100)}%</span>
            </div>
            <div className="text-[9px] text-slate-400 font-bold leading-relaxed pt-1.5 border-t border-slate-150">
              * The machine learning prediction remains subordinate and will never override clinical deterministic rules.
            </div>
          </div>

          {/* Triggers list */}
          <div className="space-y-2">
            <span className="text-[10px] font-black text-slate-400 uppercase tracking-wider block font-display">Rule Violations Triggers</span>
            <div className="space-y-1.5 max-h-[150px] overflow-y-auto pr-1">
              {currentLiveAssessment.triggeredRules.length === 0 ? (
                <p className="text-xs text-slate-400 leading-relaxed italic bg-emerald-50/30 p-3 rounded-xl border border-emerald-100/60 font-semibold">No rules violated. Vitals within normal limits.</p>
              ) : (
                currentLiveAssessment.triggeredRules.map((msg, idx) => (
                  <div key={idx} className="text-[10px] p-2.5 bg-red-50 text-red-700 rounded-xl border border-red-100 font-bold leading-normal">
                    {msg}
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Interventions recommended */}
          <div className="space-y-2">
            <span className="text-[10px] font-black text-slate-400 uppercase tracking-wider block font-display">First-line Facility Protocols</span>
            <div className="space-y-2 max-h-[150px] overflow-y-auto pr-1">
              {currentLiveAssessment.recommendedInterventions.map((act, idx) => (
                <div key={idx} className="text-[10px] p-2.5 bg-indigo-50/55 text-indigo-950 rounded-xl border border-indigo-100/60 font-bold leading-relaxed">
                  {act}
                </div>
              ))}
            </div>
          </div>

          {/* Follow up interval details */}
          <div className="pt-3 border-t border-slate-150 flex items-center justify-between text-[10px] text-slate-500 font-bold">
            <span>Clinical Follow-up Interval:</span>
            <span className="font-bold text-slate-700 bg-slate-100 px-2.5 py-1 rounded-full font-mono">{currentLiveAssessment.followUpDate}</span>
          </div>

        </div>
      </div>

    </div>
  );
}

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { ArrowLeft, Printer, ShieldAlert, CheckCircle, Signature } from 'lucide-react';
import { Patient, Visit } from '../types';

interface ReferralPrintoutProps {
  patient: Patient;
  visit: Visit;
  onBack: () => void;
}

export default function ReferralPrintout({ patient, visit, onBack }: ReferralPrintoutProps) {
  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto" id="referral-printout-root">
      
      {/* 1. Print utility toolbar (Hidden during print via css) */}
      <div className="flex justify-between items-center bg-slate-950 text-white p-4 rounded-2xl shadow-[0_4px_20px_rgba(0,0,0,0.08)] border border-slate-800 print:hidden">
        <div className="flex items-center gap-3">
          <button 
            onClick={onBack}
            className="p-2 bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white rounded-xl transition-all duration-200 hover:scale-105 active:scale-95 cursor-pointer border border-slate-800"
          >
            <ArrowLeft size={16} />
          </button>
          <div>
            <span className="text-[10px] uppercase font-black text-teal-400 block tracking-widest font-display">Referral Letter Generated</span>
            <span className="text-xs font-bold text-slate-200 font-display">Standard Primary Care Referral Format</span>
          </div>
        </div>

        <button
          onClick={handlePrint}
          className="px-4.5 py-2.5 bg-gradient-to-r from-teal-500 to-emerald-500 hover:from-teal-600 hover:to-emerald-600 text-slate-950 rounded-xl text-xs font-black flex items-center gap-2 shadow-sm hover:shadow-md transition-all duration-200 hover:scale-[1.02] active:scale-95 cursor-pointer font-display"
        >
          <Printer size={15} className="stroke-[2.5]" /> Send to Printer / Export PDF
        </button>
      </div>

      {/* 2. Official clinical document container (Print-optimized) */}
      <div className="bg-white rounded-3xl border border-slate-200/60 shadow-[0_4px_24px_rgba(0,0,0,0.03)] p-8 sm:p-12 print:border-none print:shadow-none print:p-0 font-serif text-slate-900 leading-relaxed" id="referral-letter-letterhead">
        
        {/* Document Header */}
        <div className="border-b-4 border-slate-900 pb-6 text-center space-y-2">
          <h1 className="text-xl font-black tracking-wide uppercase font-display text-slate-900">Federal Republic of Nigeria</h1>
          <h2 className="text-sm font-black uppercase tracking-widest text-slate-600 font-display">Federal Ministry of Health & Social Welfare</h2>
          <h3 className="text-xs font-bold uppercase tracking-widest text-slate-500 font-display">Maternal & Neonatal Primary Health Care Referral Scheme</h3>
          <div className="text-[10px] font-mono font-bold text-slate-400 mt-2">
            Facility: {patient.facility} • LGA: {patient.lga}, {patient.state} State
          </div>
        </div>

        {/* Document Metadata block */}
        <div className="grid grid-cols-2 gap-4 text-xs font-sans border-b border-slate-200 py-4 mt-4">
          <div>
            <span className="text-slate-400 uppercase tracking-widest block font-black text-[9px] font-display">Referral Reference:</span>
            <span className="font-bold text-slate-800 font-mono text-sm">{visit.id.replace('VIS', 'REF')}</span>
          </div>
          <div className="text-right">
            <span className="text-slate-400 uppercase tracking-widest block font-black text-[9px] font-display">Referral Date:</span>
            <span className="font-bold text-slate-800 font-mono">{visit.date}</span>
          </div>
        </div>

        {/* Primary Alert Badge */}
        <div className="my-6 p-4 border border-red-200 bg-red-50/50 rounded-2xl flex items-center gap-3.5 text-red-900 font-sans shadow-sm">
          <ShieldAlert size={22} className="shrink-0 text-red-600 animate-pulse" />
          <div className="text-xs leading-normal">
            <strong className="block uppercase tracking-wider text-red-700 font-display font-black text-[10px]">Urgent Secondary Referral Needed: {visit.riskCategory.toUpperCase()} RISK STATUS</strong>
            This pregnant woman has been classified deterministically as high risk. Immediate specialist obstetric evaluation and admission is recommended at the destination facility.
          </div>
        </div>

        {/* Section 1: Patient Biographic Data */}
        <div className="space-y-3 mt-6">
          <h4 className="text-xs font-black uppercase tracking-widest border-b border-slate-300 pb-1.5 font-display text-slate-800">I. Patient Demographic & Obstetric Summary</h4>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-8 gap-y-3 text-xs font-sans">
            <div className="flex justify-between border-b border-slate-100 pb-1.5 font-medium">
              <span className="text-slate-500">Full Patient Name:</span>
              <span className="font-bold text-slate-800">{patient.name}</span>
            </div>
            <div className="flex justify-between border-b border-slate-100 pb-1.5 font-medium">
              <span className="text-slate-500">Patient ID Number:</span>
              <span className="font-bold text-slate-800 font-mono">{patient.id}</span>
            </div>
            <div className="flex justify-between border-b border-slate-100 pb-1.5 font-medium">
              <span className="text-slate-500">Maternal Age:</span>
              <span className="font-bold text-slate-800">{patient.age} Years</span>
            </div>
            <div className="flex justify-between border-b border-slate-100 pb-1.5 font-medium">
              <span className="text-slate-500">Primary Contact Phone:</span>
              <span className="font-bold text-slate-800 font-mono">{patient.phone || 'N/A'}</span>
            </div>
            <div className="flex justify-between border-b border-slate-100 pb-1.5 font-medium">
              <span className="text-slate-500">Gravidity / Parity:</span>
              <span className="font-bold text-slate-800 font-mono">G{patient.gravidity} P{patient.parity}</span>
            </div>
            <div className="flex justify-between border-b border-slate-100 pb-1.5 font-medium">
              <span className="text-slate-500">Gestational Age / EDD:</span>
              <span className="font-bold text-slate-800 font-mono">{visit.gestationalAge} Weeks • EDD {patient.edd}</span>
            </div>
            <div className="flex justify-between border-b border-slate-100 pb-1.5 col-span-1 sm:col-span-2 font-medium">
              <span className="text-slate-500">Target Referral Facility:</span>
              <span className="font-black text-red-700 font-display">{visit.referralFacility || 'General Hospital Garki'}</span>
            </div>
          </div>
        </div>

        {/* Section 2: Clinical Physical Inputs & Labs */}
        <div className="space-y-3 mt-8">
          <h4 className="text-xs font-black uppercase tracking-widest border-b border-slate-300 pb-1.5 font-display text-slate-800">II. Admission Clinical Diagnostics & Labs</h4>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs font-sans">
            <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200/60 shadow-sm">
              <span className="text-slate-400 block uppercase tracking-wider text-[9px] font-black font-display">Blood Pressure</span>
              <span className="text-sm font-black text-slate-800 font-mono">{visit.systolic}/{visit.diastolic} <span className="text-[10px] font-bold text-slate-500">mmHg</span></span>
            </div>
            <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200/60 shadow-sm">
              <span className="text-slate-400 block uppercase tracking-wider text-[9px] font-black font-display">Haemoglobin</span>
              <span className="text-sm font-black text-slate-800 font-mono">{visit.hb} <span className="text-[10px] font-bold text-slate-500">g/dL</span></span>
            </div>
            <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200/60 shadow-sm">
              <span className="text-slate-400 block uppercase tracking-wider text-[9px] font-black font-display">Urine Protein</span>
              <span className="text-sm font-black text-slate-800 font-mono">{visit.urineProtein.toUpperCase()}</span>
            </div>
            <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200/60 shadow-sm">
              <span className="text-slate-400 block uppercase tracking-wider text-[9px] font-black font-display">Fetal Heart Rate</span>
              <span className="text-sm font-black text-slate-800 font-mono">{visit.fetalHeartRate || 'N/A'} <span className="text-[10px] font-bold text-slate-500">bpm</span></span>
            </div>
          </div>
        </div>

        {/* Section 3: Justification & Triggers */}
        <div className="space-y-3 mt-8">
          <h4 className="text-xs font-black uppercase tracking-widest border-b border-slate-300 pb-1.5 font-display text-slate-800">III. Triggered Clinical Protocols & Findings</h4>
          <div className="space-y-3 text-xs font-sans leading-normal">
            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200/60 space-y-2.5 shadow-sm">
              <span className="font-black text-slate-700 block uppercase tracking-wider text-[9px] font-display">Decision Rules Tripped:</span>
              <ul className="list-disc list-inside space-y-1 text-slate-650 pl-1.5 font-medium leading-relaxed">
                {visit.triggeredRules.map((rule, idx) => (
                  <li key={idx} className="leading-relaxed">{rule}</li>
                ))}
              </ul>
            </div>
            <div className="p-4 bg-red-50 text-red-900 rounded-xl border border-red-100 shadow-sm">
              <span className="font-black block uppercase tracking-wider text-[9px] text-red-800 font-display">Critical Symptoms Documented:</span>
              <div className="flex flex-wrap gap-2 mt-2">
                {Object.entries(visit.symptoms).filter(([_, v]) => v).length === 0 ? (
                  <span className="font-bold text-slate-500 italic text-[11px]">None recorded</span>
                ) : (
                  Object.entries(visit.symptoms)
                    .filter(([_, v]) => v)
                    .map(([k]) => (
                      <span key={k} className="px-2.5 py-1 bg-white border border-red-200 text-red-700 rounded-lg text-[10px] font-black uppercase tracking-wide font-display shadow-sm">
                        {k.replace(/([A-Z])/g, ' $1').trim()}
                      </span>
                    ))
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Section 4: AI Assisted Explanation for receiving clinicians */}
        <div className="space-y-3 mt-8">
          <h4 className="text-xs font-black uppercase tracking-widest border-b border-slate-300 pb-1.5 font-display text-slate-800">IV. Case Narrative & Clinical Justification</h4>
          <p className="text-xs text-slate-700 leading-relaxed bg-teal-50/20 p-4.5 rounded-2xl border border-teal-100 italic font-medium shadow-sm">
            "{visit.explanation || 'This maternal patient was referred due to calculated high-risk indicators under FCT / WHO Antenatal care guidelines.'}"
          </p>
        </div>

        {/* Section 5: Administered First-line Interventions */}
        <div className="space-y-3 mt-8">
          <h4 className="text-xs font-black uppercase tracking-widest border-b border-slate-300 pb-1.5 font-display text-slate-800">V. First-line Facility Treatment Administered</h4>
          <div className="bg-slate-50 p-4.5 rounded-2xl border border-slate-200/60 text-xs font-sans space-y-2 shadow-sm">
            <span className="font-black text-slate-700 block uppercase tracking-wider text-[9px] font-display">Administered Medication & Stabilizations:</span>
            <ul className="list-disc list-inside space-y-2 text-slate-650 pl-1.5 font-medium leading-relaxed">
              {visit.recommendedInterventions.map((act, idx) => (
                <li key={idx}>{act}</li>
              ))}
              <li className="text-slate-800 font-bold list-none mt-2.5 pt-2.5 border-t border-slate-200 flex items-center gap-1.5 text-teal-800">
                <CheckCircle size={14} className="stroke-[2.5]" /> Patient placed on left lateral position, vital logs monitored, transport stabilization package initialized.
              </li>
            </ul>
          </div>
        </div>

        {/* Section 6: Official Sign-off and signatures */}
        <div className="mt-12 pt-8 border-t border-slate-200 grid grid-cols-2 gap-8 text-xs font-sans" id="signature-block">
          <div>
            <span className="text-slate-400 uppercase tracking-widest block font-black text-[9px] mb-8 font-display">Referring Primary Care Provider:</span>
            <div className="border-b border-slate-400 pb-2 space-y-1">
              <span className="font-bold text-slate-800 block text-sm">{visit.clinicianName}</span>
              <span className="text-slate-500 block uppercase tracking-wider text-[10px] font-semibold">{visit.clinicianRole} — Facility Midwife Ledger</span>
            </div>
          </div>

          <div className="text-right flex flex-col justify-end">
            <span className="text-slate-400 uppercase tracking-widest block font-black text-[9px] mb-4 font-display">Official Facility Stamp:</span>
            <div className="h-16 w-32 border-2 border-dashed border-slate-350 rounded-xl flex items-center justify-center text-[10px] text-slate-400 font-mono self-end shadow-inner bg-slate-50/50">
              STAMP HERE
            </div>
          </div>
        </div>

      </div>

    </div>
  );
}


/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { 
  ArrowLeft, 
  Calendar, 
  User, 
  Phone, 
  Building2, 
  ChevronRight, 
  ChevronDown,
  Activity, 
  TrendingUp, 
  Droplet, 
  AlertTriangle,
  Scale,
  Signature,
  FileText,
  BrainCircuit,
  CornerDownRight
} from 'lucide-react';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  Legend 
} from 'recharts';
import { Patient, Visit } from '../types';

interface PatientDetailsProps {
  patient: Patient;
  visits: Visit[];
  onBack: () => void;
  onNewVisit: () => void;
  onPrintReferral: (visit: Visit) => void;
}

export default function PatientDetails({ patient, visits, onBack, onNewVisit, onPrintReferral }: PatientDetailsProps) {
  const [expandedVisitId, setExpandedVisitId] = React.useState<string | null>(
    visits.length > 0 ? visits[visits.length - 1].id : null
  );

  const toggleVisit = (id: string) => {
    if (expandedVisitId === id) {
      setExpandedVisitId(null);
    } else {
      setExpandedVisitId(id);
    }
  };

  // Compile trend data for Recharts
  const trendData = visits.map(v => {
    let riskScore = 1;
    if (v.riskCategory === 'moderate') riskScore = 2;
    if (v.riskCategory === 'high') riskScore = 3;
    if (v.riskCategory === 'emergency') riskScore = 4;

    return {
      date: v.date,
      systolic: v.systolic,
      diastolic: v.diastolic,
      weight: v.weight,
      hb: v.hb,
      risk: riskScore
    };
  });

  const getRiskLabel = (score: number) => {
    if (score === 4) return 'EMERGENCY';
    if (score === 3) return 'HIGH';
    if (score === 2) return 'MODERATE';
    return 'LOW';
  };

  return (
    <div className="space-y-6" id="patient-details-root">
      
      {/* Back navigation & primary CTA */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <button 
          onClick={onBack}
          className="flex items-center gap-2 text-xs font-bold text-slate-500 hover:text-slate-800 transition-all duration-200 hover:scale-[1.02] active:scale-95 cursor-pointer"
        >
          <ArrowLeft size={15} /> Back to Dashboard
        </button>
        <button 
          onClick={onNewVisit}
          className="px-4.5 py-2.5 bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-700 hover:to-emerald-700 text-white rounded-xl text-xs font-bold shadow-sm hover:shadow-md transition-all duration-200 hover:scale-[1.02] active:scale-95 cursor-pointer"
        >
          Record Antenatal Visit
        </button>
      </div>

      {/* Patient demographics dossier card */}
      <div className="bg-white rounded-2xl border border-slate-200/60 shadow-[0_2px_12px_rgba(0,0,0,0.03)] p-6 grid grid-cols-1 md:grid-cols-3 gap-6" id="patient-demographics-card">
        
        {/* Left Col: Biographics */}
        <div className="space-y-4 md:border-r md:border-slate-100 md:pr-6">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-teal-50 text-teal-600 rounded-full">
              <User size={22} className="stroke-[2.5]" />
            </div>
            <div>
              <h2 className="text-lg font-black text-slate-800 font-display tracking-tight leading-none">{patient.name}</h2>
              <span className="text-[10px] text-slate-400 font-mono font-bold mt-1 block uppercase tracking-wider">{patient.id}</span>
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-4 text-xs pt-2 font-medium">
            <div>
              <span className="text-slate-400 block font-bold text-[10px] uppercase tracking-wider font-display">Maternal Age</span>
              <span className="font-bold text-slate-700 font-mono text-sm">{patient.age} yrs</span>
            </div>
            <div className="flex items-center gap-1.5">
              <Phone size={14} className="text-slate-400 shrink-0" />
              <div>
                <span className="text-slate-400 block font-bold text-[10px] uppercase tracking-wider font-display">Phone</span>
                <span className="font-bold text-slate-700 font-mono">{patient.phone || 'N/A'}</span>
              </div>
            </div>
            <div>
              <span className="text-slate-400 block font-bold text-[10px] uppercase tracking-wider font-display">LGA / State</span>
              <span className="font-bold text-slate-700">{patient.lga}, {patient.state}</span>
            </div>
            <div className="flex items-center gap-1.5">
              <Building2 size={14} className="text-slate-400 shrink-0" />
              <div>
                <span className="text-slate-400 block font-bold text-[10px] uppercase tracking-wider font-display">Facility Code</span>
                <span className="font-bold text-slate-700 font-mono">{patient.facility}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Center Col: Obstetric Profile */}
        <div className="space-y-4 md:border-r md:border-slate-100 md:px-6">
          <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-wider font-display">Antenatal Obstetric Profile</h3>
          
          <div className="grid grid-cols-2 gap-4 text-xs font-semibold">
            <div>
              <span className="text-slate-400 block font-bold text-[10px] uppercase tracking-wider font-display">Gravidity (Total Preg)</span>
              <span className="text-base font-black text-slate-800 font-mono">G{patient.gravidity}</span>
            </div>
            <div>
              <span className="text-slate-400 block font-bold text-[10px] uppercase tracking-wider font-display">Parity (Prior Births)</span>
              <span className="text-base font-black text-slate-800 font-mono">P{patient.parity}</span>
            </div>
            <div>
              <span className="text-slate-400 block font-bold text-[10px] uppercase tracking-wider font-display">Gestational Age</span>
              <span className="text-base font-black text-teal-700 font-mono">{patient.gestationalAge} Weeks</span>
            </div>
            <div className="flex items-center gap-1.5">
              <Calendar size={14} className="text-teal-600 shrink-0" />
              <div>
                <span className="text-slate-400 block font-bold text-[10px] uppercase tracking-wider font-display">Calculated EDD</span>
                <span className="font-bold text-slate-700 font-mono">{patient.edd}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Right Col: High-Risk Obstetrics History */}
        <div className="space-y-3 md:pl-6">
          <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-wider font-display">High-Risk Obstetric History</h3>
          
          <div className="space-y-2 pt-1">
            <div className="flex items-center justify-between text-xs p-2 rounded-lg bg-slate-50 border border-slate-150">
              <span className="text-slate-500 font-bold font-display text-[11px]">Previous Caesarean Section</span>
              <span className={`px-2.5 py-0.5 rounded-full font-black uppercase text-[9px] tracking-wide border shadow-sm
                ${patient.previousCS ? 'bg-red-50 text-red-700 border-red-200' : 'bg-emerald-50 text-emerald-700 border-emerald-200'}`}>
                {patient.previousCS ? 'YES' : 'NO'}
              </span>
            </div>

            <div className="flex items-center justify-between text-xs p-2 rounded-lg bg-slate-50 border border-slate-150">
              <span className="text-slate-500 font-bold font-display text-[11px]">Previous Stillbirth</span>
              <span className={`px-2.5 py-0.5 rounded-full font-black uppercase text-[9px] tracking-wide border shadow-sm
                ${patient.previousStillbirth ? 'bg-red-50 text-red-700 border-red-200' : 'bg-emerald-50 text-emerald-700 border-emerald-200'}`}>
                {patient.previousStillbirth ? 'YES' : 'NO'}
              </span>
            </div>

            <div className="flex items-center justify-between text-xs p-2 rounded-lg bg-slate-50 border border-slate-150">
              <span className="text-slate-500 font-bold font-display text-[11px]">Previous PPH</span>
              <span className={`px-2.5 py-0.5 rounded-full font-black uppercase text-[9px] tracking-wide border shadow-sm
                ${patient.previousPPH ? 'bg-red-50 text-red-700 border-red-200' : 'bg-emerald-50 text-emerald-700 border-emerald-200'}`}>
                {patient.previousPPH ? 'YES' : 'NO'}
              </span>
            </div>
          </div>
        </div>

      </div>

      {/* Historic vital signs trends using Recharts */}
      {visits.length > 1 && (
        <div className="bg-white rounded-2xl border border-slate-200/60 shadow-[0_2px_12px_rgba(0,0,0,0.03)] hover:shadow-[0_4px_16px_rgba(0,0,0,0.05)] transition-all duration-300 p-6" id="patient-trends-charts">
          <h3 className="text-sm font-bold text-slate-800 mb-6 flex items-center gap-2 font-display">
            <TrendingUp className="text-teal-600 stroke-[2.5]" size={16} /> Patient Antenatal Vital Trends
          </h3>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            {/* Blood Pressure Trend */}
            <div className="space-y-2">
              <span className="text-[10px] font-black text-slate-400 block text-center uppercase tracking-wider font-display">Blood Pressure (mmHg)</span>
              <div className="h-[150px]">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={trendData} margin={{ top: 5, right: 10, left: -20, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                    <XAxis dataKey="date" stroke="#94a3b8" fontSize={9} />
                    <YAxis domain={[50, 180]} stroke="#94a3b8" fontSize={9} />
                    <Tooltip contentStyle={{ fontSize: '10px', borderRadius: '12px', border: '1px solid #e2e8f0', boxShadow: '0 4px 12px rgba(0,0,0,0.04)' }} />
                    <Line type="monotone" dataKey="systolic" name="Systolic" stroke="#ef4444" strokeWidth={2.5} activeDot={{ r: 4 }} />
                    <Line type="monotone" dataKey="diastolic" name="Diastolic" stroke="#3b82f6" strokeWidth={2.5} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Haemoglobin Trend */}
            <div className="space-y-2">
              <span className="text-[10px] font-black text-slate-400 block text-center uppercase tracking-wider font-display">Haemoglobin (g/dL)</span>
              <div className="h-[150px]">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={trendData} margin={{ top: 5, right: 10, left: -20, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                    <XAxis dataKey="date" stroke="#94a3b8" fontSize={9} />
                    <YAxis domain={[5, 15]} stroke="#94a3b8" fontSize={9} />
                    <Tooltip contentStyle={{ fontSize: '10px', borderRadius: '12px', border: '1px solid #e2e8f0', boxShadow: '0 4px 12px rgba(0,0,0,0.04)' }} />
                    <Line type="monotone" dataKey="hb" name="Haemoglobin" stroke="#06b6d4" strokeWidth={2.5} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Risk Category Trend */}
            <div className="space-y-2">
              <span className="text-[10px] font-black text-slate-400 block text-center uppercase tracking-wider font-display">Calculated Clinical Risk Profile</span>
              <div className="h-[150px]">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={trendData} margin={{ top: 5, right: 10, left: -20, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                    <XAxis dataKey="date" stroke="#94a3b8" fontSize={9} />
                    <YAxis 
                      domain={[1, 4]} 
                      ticks={[1, 2, 3, 4]} 
                      tickFormatter={(v) => getRiskLabel(v)} 
                      stroke="#94a3b8" 
                      fontSize={8} 
                    />
                    <Tooltip contentStyle={{ fontSize: '10px', borderRadius: '12px', border: '1px solid #e2e8f0', boxShadow: '0 4px 12px rgba(0,0,0,0.04)' }} formatter={(v: any) => [getRiskLabel(v), 'Risk Level']} />
                    <Line type="stepAfter" dataKey="risk" name="Clinical Risk" stroke="#f59e0b" strokeWidth={2.5} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>

          </div>
        </div>
      )}

      {/* Timeline Visit History Ledger */}
      <div className="space-y-4" id="patient-visits-ledger">
        <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2 font-display">
          <Activity className="text-teal-600 stroke-[2.5]" size={16} /> Clinical Antenatal Contact History ({visits.length})
        </h3>

        {visits.length === 0 ? (
          <div className="bg-white rounded-2xl border border-slate-100 p-8 text-center text-slate-400 text-xs">
            No antenatal visits have been recorded yet for this patient. Click "Record Antenatal Visit" above.
          </div>
        ) : (
          <div className="space-y-3">
            {[...visits].reverse().map((visit) => {
              const isOpen = expandedVisitId === visit.id;
              
              return (
                <div key={visit.id} className="bg-white rounded-2xl border border-slate-200/60 shadow-[0_2px_12px_rgba(0,0,0,0.03)] overflow-hidden transition-all duration-300 hover:shadow-[0_4px_16px_rgba(0,0,0,0.05)]" id={`visit-ledger-${visit.id}`}>
                  
                  {/* Collapsed visit header banner */}
                  <div 
                    onClick={() => toggleVisit(visit.id)}
                    className="p-4.5 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 cursor-pointer hover:bg-slate-50/40 transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      {isOpen ? <ChevronDown size={16} className="text-slate-500 stroke-[2.5]" /> : <ChevronRight size={16} className="text-slate-500 stroke-[2.5]" />}
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-bold text-slate-800 font-display">Visit Ref: {visit.id}</span>
                          <span className="text-[10px] text-slate-400 font-bold font-mono">({visit.date})</span>
                        </div>
                        <div className="text-[10px] text-slate-400 font-semibold mt-1">Gestational Age: <strong className="text-slate-600 font-mono">{visit.gestationalAge} Wks</strong> • Logged by <strong className="text-slate-600 font-display">{visit.clinicianName}</strong> ({visit.clinicianRole.toUpperCase()})</div>
                      </div>
                    </div>

                    <div className="flex items-center gap-3 self-end sm:self-auto">
                      <span className={`inline-block px-3 py-1 rounded-full font-bold uppercase text-[9px] tracking-wider text-center border shadow-sm
                        ${visit.riskCategory === 'emergency' ? 'bg-red-50 text-red-700 border-red-200' : ''}
                        ${visit.riskCategory === 'high' ? 'bg-orange-50 text-orange-700 border-orange-200' : ''}
                        ${visit.riskCategory === 'moderate' ? 'bg-amber-50 text-amber-700 border-amber-200' : ''}
                        ${visit.riskCategory === 'low' ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : ''}
                      `}>
                        {visit.riskCategory}
                      </span>
                    </div>
                  </div>

                  {/* Expanded detailed clinical visit card */}
                  {isOpen && (
                    <div className="p-6 border-t border-slate-100 bg-slate-50/30 space-y-6">
                      
                      {/* Subgrid: Clincal physical inputs & laboratory findings */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                        
                        {/* Physical Vitals block */}
                        <div className="bg-white p-4 rounded-xl border border-slate-200/80 shadow-[0_1px_4px_rgba(0,0,0,0.02)] space-y-3">
                          <span className="text-[10px] font-black text-slate-400 uppercase tracking-wider block font-display">Physical Vitals</span>
                          <div className="grid grid-cols-2 gap-y-2 gap-x-1 text-xs font-medium">
                            <div>
                              <span className="text-slate-400">BP:</span>
                              <span className={`font-bold ml-1 font-mono ${visit.systolic >= 140 || visit.diastolic >= 90 ? 'text-red-600' : 'text-slate-700'}`}>
                                {visit.systolic}/{visit.diastolic}
                              </span>
                            </div>
                            <div>
                              <span className="text-slate-400">Weight:</span>
                              <span className="font-bold text-slate-700 ml-1 font-mono">{visit.weight} kg</span>
                            </div>
                            <div>
                              <span className="text-slate-400">Temp:</span>
                              <span className={`font-bold ml-1 font-mono ${visit.temperature > 37.8 ? 'text-red-600' : 'text-slate-700'}`}>
                                {visit.temperature} °C
                              </span>
                            </div>
                            <div>
                              <span className="text-slate-400">Pulse:</span>
                              <span className="font-bold text-slate-700 ml-1 font-mono">{visit.pulse} bpm</span>
                            </div>
                          </div>
                        </div>

                        {/* Laboratory Results */}
                        <div className="bg-white p-4 rounded-xl border border-slate-200/80 shadow-[0_1px_4px_rgba(0,0,0,0.02)] space-y-3">
                          <span className="text-[10px] font-black text-slate-400 uppercase tracking-wider block font-display">Laboratory Results</span>
                          <div className="grid grid-cols-2 gap-y-2 gap-x-1 text-xs font-medium font-mono">
                            <div>
                              <span className="text-slate-400 font-sans">Hb:</span>
                              <span className={`font-bold ml-1 ${visit.hb < 11 ? 'text-amber-600 font-black' : 'text-slate-700'}`}>
                                {visit.hb} g/dL
                              </span>
                            </div>
                            <div>
                              <span className="text-slate-400 font-sans">Prot:</span>
                              <span className={`font-bold ml-1 ${visit.urineProtein !== 'negative' ? 'text-red-600 font-black' : 'text-slate-700'}`}>
                                {visit.urineProtein}
                              </span>
                            </div>
                            <div>
                              <span className="text-slate-400 font-sans">Sug:</span>
                              <span className={`font-bold ml-1 ${visit.urineGlucose !== 'negative' ? 'text-amber-600' : 'text-slate-700'}`}>
                                {visit.urineGlucose}
                              </span>
                            </div>
                            <div>
                              <span className="text-slate-400 font-sans">Rh/Gp:</span>
                              <span className="font-bold text-slate-700 ml-1">
                                {visit.bloodGroup || 'N/A'}{visit.rhesus}
                              </span>
                            </div>
                          </div>
                        </div>

                        {/* Obstetric Exam */}
                        <div className="bg-white p-4 rounded-xl border border-slate-200/80 shadow-[0_1px_4px_rgba(0,0,0,0.02)] space-y-3">
                          <span className="text-[10px] font-black text-slate-400 uppercase tracking-wider block font-display">Obstetric Examination</span>
                          <div className="grid grid-cols-2 gap-y-2 gap-x-1 text-xs font-medium">
                            <div>
                              <span className="text-slate-400">Fundal:</span>
                              <span className="font-bold text-slate-700 ml-1 font-mono">{visit.fundalHeight || 'N/A'} cm</span>
                            </div>
                            <div>
                              <span className="text-slate-400">FHR:</span>
                              <span className={`font-bold ml-1 font-mono ${visit.fetalHeartRate > 0 && (visit.fetalHeartRate < 110 || visit.fetalHeartRate > 160) ? 'text-red-600' : 'text-slate-700'}`}>
                                {visit.fetalHeartRate || 'N/A'}
                              </span>
                            </div>
                            <div className="col-span-2">
                              <span className="text-slate-400">Fetal Mov:</span>
                              <span className={`font-bold ml-1 uppercase text-[10px] ${visit.fetalMovement !== 'normal' ? 'text-red-650' : 'text-emerald-700'}`}>
                                {visit.fetalMovement}
                              </span>
                            </div>
                            <div className="col-span-2">
                              <span className="text-slate-400">Presentation:</span>
                              <span className="font-bold text-slate-700 ml-1 uppercase text-[10px]">{visit.presentation}</span>
                            </div>
                          </div>
                        </div>

                        {/* Symptoms Flagged */}
                        <div className="bg-white p-4 rounded-xl border border-slate-200/80 shadow-[0_1px_4px_rgba(0,0,0,0.02)] space-y-3">
                          <span className="text-[10px] font-black text-slate-400 uppercase tracking-wider block font-display">Symptoms Flagged</span>
                          <div className="flex flex-wrap gap-1.5 pt-0.5">
                            {Object.entries(visit.symptoms).filter(([_, v]) => v).length === 0 ? (
                              <span className="text-[10px] text-emerald-700 bg-emerald-50/50 border border-emerald-200 px-2.5 py-1 rounded-lg font-bold uppercase tracking-wider">No Warning Signs</span>
                            ) : (
                              Object.entries(visit.symptoms)
                                .filter(([_, v]) => v)
                                .map(([k]) => (
                                  <span key={k} className="text-[9px] font-bold uppercase bg-red-50 text-red-700 border border-red-200 px-2 py-0.5 rounded shadow-sm">
                                    {k.replace(/([A-Z])/g, ' $1').trim()}
                                  </span>
                                ))
                            )}
                          </div>
                        </div>

                      </div>

                      {/* AI Clinical explanation generated securely on server */}
                      <div className="bg-gradient-to-r from-teal-50 to-teal-50/10 p-5 rounded-2xl border border-teal-100/80 space-y-2">
                        <div className="flex items-center gap-2 text-xs font-bold text-teal-850 font-display">
                          <BrainCircuit size={16} className="text-teal-600 stroke-[2.5]" /> Secure Clinical AI Decryption & Explanation
                        </div>
                        <p className="text-xs text-slate-700 leading-relaxed italic font-medium pl-6">
                          "{visit.explanation || 'An explanation could not be generated for this record.'}"
                        </p>
                        <div className="text-[9px] text-teal-600 font-bold uppercase tracking-wider pl-6 pt-1 font-mono">
                          Processed via server-side Gemini 2.5 • Strictly uncoupled from deterministic logic
                        </div>
                      </div>

                      {/* Risk Engine Justification Box */}
                      <div className="bg-white p-5 rounded-2xl border border-slate-200/80 grid grid-cols-1 md:grid-cols-2 gap-6 shadow-[0_1px_4px_rgba(0,0,0,0.01)]">
                        
                        {/* Triggered rules and findings */}
                        <div className="space-y-3">
                          <span className="text-[10px] font-black text-slate-400 uppercase tracking-wider flex items-center gap-1.5 font-display">
                            <AlertTriangle className="text-amber-500 stroke-[2.5]" size={14} /> Triggered Decision Guidelines
                          </span>
                          <div className="space-y-2">
                            {visit.triggeredRules.length === 0 ? (
                              <div className="text-xs text-slate-400 font-medium italic p-3 bg-slate-50 rounded-xl border border-slate-100">No rule triggers tripped. Patient exhibits standard baseline clinical vitals.</div>
                            ) : (
                              visit.triggeredRules.map((rule, idx) => (
                                <div key={idx} className="flex gap-2.5 items-start text-xs text-slate-700 bg-slate-50/70 p-3 rounded-xl border border-slate-150 font-medium">
                                  <CornerDownRight size={13} className="text-slate-400 mt-0.5 shrink-0" />
                                  <span>{rule}</span>
                                </div>
                              ))
                            )}
                          </div>
                        </div>

                        {/* Recommended Interventions */}
                        <div className="space-y-3">
                          <span className="text-[10px] font-black text-slate-400 uppercase tracking-wider flex items-center gap-1.5 font-display">
                            <FileText className="text-indigo-600 stroke-[2.5]" size={14} /> Recommended Action & Protocols
                          </span>
                          <div className="space-y-2">
                            {visit.recommendedInterventions.map((action, idx) => (
                              <div key={idx} className="text-xs text-indigo-900 bg-indigo-50/40 p-3 rounded-xl border border-indigo-100/50 leading-relaxed font-semibold">
                                {action}
                              </div>
                            ))}
                            {visit.referralNeeded && (
                              <div className="text-xs text-red-950 bg-red-50/50 p-3 rounded-xl border border-red-100 font-bold flex flex-col gap-1.5">
                                <span className="flex items-center gap-1.5 text-red-700 font-display">⚠️ Refer to Secondary Care Facility for Delivery Planning:</span>
                                <span className="font-mono text-[10px] text-red-700 bg-white px-2.5 py-1 rounded-lg border border-red-200 mt-1 self-start font-black shadow-sm">
                                  Target: {visit.referralFacility || 'General Hospital Garki'}
                                </span>
                              </div>
                            )}
                          </div>
                        </div>

                      </div>

                      {/* Optional Machine Learning predictions */}
                      <div className="bg-slate-50/80 p-3.5 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-3 text-[10px] text-slate-400 border border-slate-200 font-bold">
                        <div className="flex items-center gap-2">
                          <Activity size={14} className="text-teal-600" />
                          <span>Determined Follow-Up Plan: <strong className="text-slate-700 font-mono font-black">{visit.followUpDate}</strong></span>
                        </div>
                        
                        <div className="flex items-center gap-4">
                          <div className="flex items-center gap-1.5">
                            <BrainCircuit size={12} className="text-teal-600" />
                            <span>Risk Prediction Probability: <strong className="text-slate-700 font-mono font-black">{(visit.mlProbability * 100).toFixed(0)}%</strong></span>
                          </div>
                          <div className="flex items-center gap-1.5">
                            <Scale size={12} className="text-teal-600" />
                            <span>ML Model Confidence: <strong className="text-slate-700 font-mono font-black">{(visit.mlConfidence * 100).toFixed(0)}%</strong></span>
                          </div>
                        </div>
                      </div>

                      {/* Actions: Print Referral Letter */}
                      {visit.referralNeeded && (
                        <div className="flex justify-end pt-2 border-t border-slate-150">
                          <button
                            onClick={() => onPrintReferral(visit)}
                            className="text-xs font-bold px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl flex items-center gap-2 shadow-sm transition-all duration-200 hover:scale-[1.02] active:scale-95 cursor-pointer"
                          >
                            <FileText size={14} /> Generate Standard Referral Printout
                          </button>
                        </div>
                      )}

                    </div>
                  )}

                </div>
              );
            })}
          </div>
        )}
      </div>

    </div>
  );
}

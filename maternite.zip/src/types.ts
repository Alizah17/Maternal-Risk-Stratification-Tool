/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type RiskLevel = 'low' | 'moderate' | 'high' | 'emergency';

export type UserRole = 'midwife' | 'chew' | 'admin' | 'district_officer' | 'state_manager';

export interface Patient {
  id: string; // E.g., MAT-2026-001
  name: string;
  age: number;
  phone: string;
  lga: string;
  state: string;
  facility: string;
  gravidity: number;
  parity: number;
  edd: string; // YYYY-MM-DD
  gestationalAge: number; // in weeks
  previousCS: boolean;
  previousStillbirth: boolean;
  previousPPH: boolean; // Postpartum haemorrhage
  createdAt: string;
  syncStatus?: 'synced' | 'pending';
}

export interface ClinicalSymptoms {
  headache: boolean;
  blurredVision: boolean;
  swelling: boolean; // especially face/hands
  bleeding: boolean;
  convulsions: boolean;
  fever: boolean;
  reducedFetalMovement: boolean;
  abdominalPain: boolean;
  vomiting: boolean;
}

export interface MedicalHistory {
  hypertension: boolean;
  diabetes: boolean;
  hiv: boolean;
  malaria: boolean;
  sickleCell: boolean;
  tuberculosis: boolean;
  multiplePregnancy: boolean;
  smoking: boolean;
  alcohol: boolean;
  drugUse: boolean;
  previousPreeclampsia: boolean;
}

export interface Visit {
  id: string;
  patientId: string;
  date: string;
  gestationalAge: number; // in weeks at time of visit
  
  // Vitals
  systolic: number; // mmHg
  diastolic: number; // mmHg
  weight: number; // kg
  height: number; // cm
  bmi: number;
  temperature: number; // °C
  pulse: number; // bpm
  respRate: number; // bpm
  
  // Labs
  hb: number; // g/dL
  urineProtein: 'negative' | '1+' | '2+' | '3+' | '4+';
  urineGlucose: 'negative' | '1+' | '2+' | '3+' | '4+';
  bloodGroup: 'A' | 'B' | 'AB' | 'O' | '';
  rhesus: '+' | '-' | '';
  
  // Obstetric
  fundalHeight: number; // cm
  fetalHeartRate: number; // bpm
  fetalMovement: 'normal' | 'reduced' | 'absent';
  presentation: 'cephalic' | 'breech' | 'shoulder' | 'transverse' | 'unknown';
  
  // Questionnaires
  symptoms: ClinicalSymptoms;
  history: MedicalHistory;
  
  // Deterministic engine outputs
  riskCategory: RiskLevel;
  triggeredRules: string[];
  clinicalFindings: string[];
  recommendedInterventions: string[];
  referralNeeded: boolean;
  referralFacility?: string;
  followUpDate: string;
  
  // ML prediction placeholder
  mlProbability: number; // 0.0 to 1.0
  mlConfidence: number; // 0.0 to 1.0
  
  // LLM summary explanation (optional, loaded from server)
  explanation?: string;
  
  // Clinical metadata
  clinicianRole: UserRole;
  clinicianName: string;
  
  // Offline sync marker
  syncStatus: 'synced' | 'pending';
}

export interface FacilityStats {
  id: string;
  name: string;
  totalPatients: number;
  totalVisits: number;
  riskDistribution: {
    low: number;
    moderate: number;
    high: number;
    emergency: number;
  };
  referralRate: number;
  avgHb: number;
  avgBPSystolic: number;
  avgBPDiastolic: number;
}
